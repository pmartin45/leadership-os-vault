# This folder unlocks in Session 3

You'll fill this folder during Session 3: *Run a System That Scales*.

What lives here:

- **Delegation Briefs** — one per task you hand off, structured around the 7 Levels of Delegation. Each brief locks: the outcome, the level (Tell → Delegate Fully), the constraints, the check-in cadence, and the definition of done.

The template lands in your vault during Session 3.
