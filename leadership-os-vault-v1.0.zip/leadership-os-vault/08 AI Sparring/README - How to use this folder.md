# AI Sparring

This is where Claude conversations that mattered come to live.

## What goes here

When a session with your Claude Project produces something worth keeping — a draft that landed, a reframe that cracked a stuck stakeholder problem, a sequence of prompts that gave you a much better Weekly Update than usual — copy the relevant part of the conversation into a new file here.

## What doesn't go here

Throwaway chats. The point of this folder isn't to be a log. It's to be a library of the moves that worked, so you can reuse them.

## Naming convention

`YYYY-MM-DD - [Topic] - [What worked]`

Examples:

- `2026-06-09 - Sarah churn pushback - reframe via TIMO`
- `2026-06-12 - Weekly update tone - shorter, more direct`
- `2026-06-15 - Daniel 1-1 prep - 7 levels brief`

## When to revisit

End of every month, skim this folder. The patterns will surprise you. The prompts you reach for most often become your durable assets — promote them into the Claude Project itself.
