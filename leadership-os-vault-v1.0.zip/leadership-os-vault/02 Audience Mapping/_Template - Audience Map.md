# Audience Map: [Stakeholder Name]

> Duplicate this file, rename it to the stakeholder, fill it in.

## Who they are

- **Name:** 
- **Role / title:** 
- **Relationship to you:** *(peer / boss / cross-functional / report)*

## What they care about most

*Top 3 priorities — what wakes them up at 3am.*

- 
- 
- 

## What they're worried about right now

*Their current pressure, the thing on their plate this quarter.*

- 

## How they consume information

- **Format preference:** *(1-pager / slides / Slack / verbal)*
- **Length tolerance:** *(one screen / three slides / a memo)*
- **The "so what" first?** *(yes/no — most senior people: yes)*

## What makes them shut down

*Triggers. The phrasing, framing, or behaviour that costs you trust.*

- 

## What a great outcome looks like for them

*When they leave the meeting happy, what just happened?*

- 

## Current state of the relationship

*Where you stand right now. Recent wins, recent friction, open questions.*

- 

## Notes for Claude

*Anything Claude needs to know when drafting messages to this person — their language patterns, what to avoid, examples of phrasing that worked before.*

- 
