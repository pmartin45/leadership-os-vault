# Audience Map: Sarah (CMO)

## Who they are

- **Name:** Sarah Chen
- **Role / title:** Chief Marketing Officer
- **Relationship to you:** Peer on the leadership team. Owns the revenue narrative I support with data.

## What they care about most

- Pipeline quality and acquisition cost — her board metric
- Retention story for the next QBR — she's being asked "where's the leaky bucket?"
- Brand health — quieter priority but hers personally

## What they're worried about right now

- Q3 CAC is trending the wrong way and she doesn't have a clean answer yet
- The retention narrative is fragmented across three dashboards and nobody owns it

## How they consume information

- **Format preference:** One page. If it's slides, max five. Hates 40-slide decks.
- **Length tolerance:** Three minutes of reading or she's skimming.
- **The "so what" first?** Yes. Always. Open with the decision she needs to make.

## What makes them shut down

- Leading with methodology. She doesn't want to hear about the model, she wants the answer.
- Numbers without a recommendation. "Here's the data" is not a finish line for her.
- When the data contradicts her gut and I don't acknowledge the gap. She'll say "the data is wrong" — what she means is "explain the gap or I won't trust this."

## What a great outcome looks like for them

- She walks out with one number, one risk, one decision, one owner.

## Current state of the relationship

- Solid but bruised. She pushed back on the churn model timeline last sprint. I haven't closed that loop yet — needs a tension → insight → outcome message this week.

## Notes for Claude

- Sarah is a cyclist. She thinks in cadence, watts, gradients. Metaphors from endurance sport land well — don't force them, but they work.
- She writes in short paragraphs. Match her.
- Never open with "I wanted to share…" — open with the headline.
- When she says "the data is wrong," she's signalling distrust in framing, not numbers. Address the gap directly.
