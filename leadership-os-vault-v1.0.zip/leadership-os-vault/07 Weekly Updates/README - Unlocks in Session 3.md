# This folder unlocks in Session 3

You'll fill this folder during Session 3: *Run a System That Scales*.

What lives here:

- **Time audit** — your last 5 working days categorised as Align / Decide / Learn / Noise. The diagnostic for designing your operating rhythm.
- **Operating rhythm** — your Personal / Team / Stakeholder cadences, written down in one place.
- **Weekly Updates** — drafted weekly by your Claude Project, refined by you, sent up the chain. The standing artefact of the rhythm.

The templates land in your vault during Session 3.
