# This folder unlocks in Session 2

You'll fill this folder during Session 2: *Lead the Change*.

What lives here:

- **Change Response Matrix** — mapping the people involved in a change to Advocate / Skeptic / Observer / Withdrawn.
- **C.O.R.E. messages** — Context → Outcome → Relevance → Expectations, used for cutting through AI/change noise with a specific stakeholder.
- **T.I.M.E. drafts** — Tension → Insight → Move → Effect, used to sell change as a business case rather than a demo.

The templates land in your vault during Session 2. For now, sit tight.
