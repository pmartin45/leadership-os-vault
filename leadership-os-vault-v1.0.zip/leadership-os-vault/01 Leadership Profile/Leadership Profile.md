# Leadership Profile

> This is the context your Claude Project pulls from every session. Fill it once. Update it as your role evolves.

## Basics

- **Name:** 
- **Role / title:** 
- **Company / industry:** 
- **Team size:** 
- **Team structure:** *(direct reports + their roles, any matrix relationships)*

## Top 3 stakeholders

*The people whose buy-in shapes your quarter. One line each on what they care about most.*

1. **[Name, role]** — 
2. **[Name, role]** — 
3. **[Name, role]** — 

## Top 3 current challenges

*The things on your plate this quarter that actually matter. Not the inbox — the substance.*

1. 
2. 
3. 

## Operating context

- **Company stage:** *(startup / scale-up / enterprise / public)*
- **Where data sits in the org:** *(under CTO / CFO / CEO / standalone)*
- **Key constraints:** *(headcount frozen / tooling locked / political / regulatory)*

## How I write and speak

*Claude will draft in your voice. Tell it what your voice is.*

- **Default register:** *(formal / direct / warm / dry — pick the one closest to how you actually write)*
- **Words and phrases I use a lot:** 
- **Words and phrases I never use:** 
- **My version of a great message:** *(one or two sentences describing what "good" looks like when it comes out of your hands)*

## Notes for Claude

*Anything else Claude needs to know to be useful to you specifically. Examples: "I lead a remote-first team across three time zones." "I'm new in role, six months in." "I report to a board chair who reads everything as a memo, not a deck."*

- 
- 
- 
