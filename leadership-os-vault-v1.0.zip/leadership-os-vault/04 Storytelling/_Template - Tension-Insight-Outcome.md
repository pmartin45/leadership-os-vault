# T → I → O: [Topic]

> The spine of every executive message. Tension names the friction. Insight reframes it. Outcome makes it concrete.

## Context

- **Audience:** *(link to their audience map)*
- **The change I need to land:** *(one sentence — what's different after they read this?)*
- **The format this becomes:** *(email / 1-pager / 3-slide / verbal)*

## Tension

*The friction. What's not working, what's unresolved, what's at stake right now. Name it directly. Soft tension = soft message.*

- 

## Insight

*The non-obvious thing you're seeing that they aren't. The reframe. "Here's what's actually happening underneath" — not a recap of the tension.*

- 

## Outcome

*The specific, concrete change that follows from the insight. A decision, a number, a risk owned, a next step with a name on it. If you can't picture what changes Monday morning, the outcome isn't sharp enough.*

- 

## The draft

*(Write the actual message here. The T→I→O spine should be visible in the structure even if the words don't appear.)*

---

## Working notes

- 
