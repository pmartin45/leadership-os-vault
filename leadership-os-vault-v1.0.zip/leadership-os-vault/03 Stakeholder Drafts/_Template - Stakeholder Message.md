# Message to: [Stakeholder Name]

> Duplicate this file. Rename to: "[Date] - To [Name] - [Topic]"

## Context

- **Audience Map:** [[EXAMPLE - Sarah (CMO)]] *(replace with link to their map)*
- **What triggered this:** *(a meeting, a request, a pushback, a deadline)*
- **Format:** *(email / Slack / 1-pager / verbal — pick what their map says they prefer)*
- **Status:** draft

## What I'm trying to land

*One sentence. The decision, change, or commitment you want from them by the end of this message.*

## T → I → O breakdown

- **Tension:** 
- **Insight:** 
- **Outcome:** 

## The draft

*(Write the actual message here. Open with the headline. Match their format preference.)*

---

## Working notes

*Refinements, what you cut, what Claude suggested that you didn't use, version history.*

- 
