# Message to: Sarah (CMO)

## Context

- **Audience Map:** [[EXAMPLE - Sarah (CMO)]]
- **What triggered this:** Sarah said "the data is wrong" in last week's leadership meeting after I flagged the churn model needs two more weeks. I haven't closed the loop yet.
- **Format:** Email. Short. One screen.
- **Status:** draft, ready to send

## What I'm trying to land

Sarah agrees to a two-week extension on the churn model in exchange for a 1-page retention story she can take into the QBR.

## T → I → O breakdown

- **Tension:** The retention narrative for the QBR is fragmented across three dashboards. Shipping the churn model on Friday locks in that fragmentation.
- **Insight:** Annual and monthly customers churn for fundamentally different reasons. Modelling them as one segment is what made the first cut look wrong. They need separate interventions.
- **Outcome:** Two extra weeks → one retention page for the QBR: two segments, two bets, two owners, two numbers.

## The draft

**Subject:** Churn model — why the extra two weeks, and what you get

Sarah,

You said last week the data was wrong. You're right that the story isn't landing yet. Here's where we are and what I'm choosing to do about it.

The retention narrative for the QBR is currently spread across three dashboards. Pushing the churn model live this Friday locks that fragmentation in.

What we found in the last sprint: annual and monthly contracts churn for fundamentally different reasons. Annual churns on price at renewal. Monthly churns on activation in the first 30 days. Modelling them as one segment was the gap you were picking up on.

Two extra weeks gets you one retention page for the QBR: two segments, two bets, two owners, two numbers. Decision, risk, ask — all on one screen.

One thing I need from you: which segment matters more for the board narrative, annual or monthly? That shapes which intervention we model first.

[Your name]

---

## Working notes

- Opens with her own words back to her — earns the right to disagree.
- No methodology. She doesn't care that it's a logistic regression. She cares that the segments behave differently.
- Closes with a question she has to answer, not a status update. Keeps the loop open her way.
- Cut the original opener "I wanted to follow up on…" — her map says never open with that.
