# Leadership OS Vault

Welcome. This is your Leadership Operating System — a personal knowledge vault you own forever.

You're holding the empty version. Over the next two weeks of the cohort, you'll populate it with your real stakeholders, your real messages, your real rhythm. By Demo Day, this vault is yours — not rented, not subscription-locked, not dependent on anyone else's server.

## Before Session 1 — do these in order

1. **Open this folder in Obsidian.** File → Open folder as vault → select this folder.
2. **Watch the Pre-Work Bootcamp (60 min).** Link is in your pre-work email. It walks you through Obsidian, your Claude Project, the Sarah example, and how to fill in your Leadership Profile.
3. **Read the examples.** Open `01 Leadership Profile/EXAMPLE - Alex Chen.md`, then `02 Audience Mapping/EXAMPLE - Sarah (CMO).md`, then `03 Stakeholder Drafts/EXAMPLE - Message to Sarah re Churn Model.md`. See what "done" looks like.
4. **Fill in your `01 Leadership Profile/Leadership Profile.md`.** This is the foundation everything else builds on, and it's the context your Claude Project pulls from every session. 15 minutes.
5. **Watch the two pre-watch videos.** *Why Smart Data Leaders Don't Get Invited to the Room* (15 min) and *Saying No Without Losing Trust* (8 min).

Folders 01–04 unlock through Sessions 1–2. Folders 05–07 unlock through Sessions 2–3. Folder 08 is ongoing from day one.

## Three things to know

**1. The vault is the memory. Claude is the sparring partner.**
You'll pair this vault with a Claude Project called "My Leadership OS." Your profile, your audience maps, your past drafts — all of it lives here and gets pasted into Claude when you want to think with it. Claude doesn't remember between sessions. The vault does.

**2. The `_Template` files are the patterns. Don't edit them — duplicate them.**
Files starting with `_Template` are blueprints. Right-click → Make a copy of, then rename. The underscore keeps templates sorted to the top of each folder.

**3. The EXAMPLE files show you what "done" looks like.**
Each framework folder ships with an EXAMPLE file using Sarah, the CMO from the running case. Read those first before filling your own.

## Questions during the cohort

Drop them in the cohort thread. Everything in this vault is iterable — if a template doesn't fit how you work, change it. This is your OS.
