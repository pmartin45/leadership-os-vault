---
type: example
module: "09 Decision Log"
session: "Session 4"
framework: "C.A.L.L."
status: decided
door: two-way
confidence: 80
review: 2026-09-30
tags: [running-case, decision]
publish: true
---

# Fund the full churn rollout (€90K)

> Worked example. Do not edit. Use it as a reference for logging your own decisions.

Related: [[EXAMPLE - Weekly Update (Churn Rollout)]]

**The call.** Yes: fund the €90K full rollout of the churn model across every segment and into the campaign engine, live by Q3.

**The door.** Two-way. We can pause or pull the rollout if the numbers do not hold in the first month. That is why I am moving fast rather than demanding another quarter of analysis.

**Confidence.** 80%, because the pilot recovered €146K in two weeks on 500 accounts, roughly 14x on €8K. The honest discount: the pilot ran on the highest-risk segment, so the full-population return may land below 15x.

**What would change my mind.** If the first month of full deployment recovers less than half the per-account rate of the pilot, the business case is wrong and we pause.

**Cost of waiting.** Churn costs about €1.4M a year, caught too late. Every month of delay is roughly €120K we do not recover.

**Review date.** 2026-09-30, at the next monthly Decision Review.

---

*Fill in at review (leave blank until the review date):*

**Outcome.** [Pending review.]

**Calibration.** [Pending review.]
