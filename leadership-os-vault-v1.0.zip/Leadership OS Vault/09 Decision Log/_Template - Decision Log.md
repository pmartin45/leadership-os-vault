---
type: template
module: "09 Decision Log"
session: "Session 4"
framework: "C.A.L.L."
status: open
door: two-way
confidence: 
review: 
tags: [template, decision]
publish: true
---

# [Decision in a few words]

> Duplicate this file, rename it to the decision. Run it through [[_Reference - Decision Sparring Partner|C.A.L.L.]] in Claude, then log the result here.

**The call.** One plain sentence: what am I deciding, and what is the answer? If it takes more than a sentence, I have not decided yet.

**The door.** One-way (irreversible, I slowed down and demanded rigor) or two-way (reversible, I moved fast, I can walk it back). One line on why.

**Confidence.** ___%, and the honest reason for that number, not the number that makes me feel safe.

**What would change my mind.** The single piece of evidence or the one event that would flip this call. Be specific enough that I would actually notice it.

**Cost of waiting.** What it costs me to delay versus decide now.

**Review date.** YYYY-MM-DD, revisit at the next monthly Decision Review.

---

*Fill in at review (leave blank until the review date):*

**Outcome.** What actually happened.

**Calibration.** Was my confidence about right, too high, or too low? Did my "what would change my mind" trigger fire, and did I act on it? What do I adjust next time?
