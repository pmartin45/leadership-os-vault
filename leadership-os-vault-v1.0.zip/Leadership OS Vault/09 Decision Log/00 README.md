---
type: readme
module: "09 Decision Log"
session: "Session 4"
framework: "C.A.L.L."
tags: [readme, decision]
publish: true
---

# 09 Decision Log

Where hard calls become logged decisions you can come back to and learn from. Run on C.A.L.L.: Call it, Assess the door, Lay the odds, Log it.

## What lives here

- **A Decision Record for every real call you make under uncertainty**: the call, the door, the confidence, the trigger that would change your mind, and a review date.
- **The Decision Sparring Partner**: the framework you add to your Claude Project once, plus the prompt you paste when you are facing a decision.
- **A worked example**: the churn full-deployment funding call.

## How it grows

**Session 4** teaches C.A.L.L. and one-way versus two-way doors. Add the sparring partner to your system prompt once, then duplicate `_Template - Decision Log.md` for each real decision.

**After Session 4**: log the calls that matter, and run a monthly Decision Review against the review dates.

## The rules

- **One sentence or it is not decided.** If the call takes a paragraph, you are still hedging.
- **Most calls are two-way doors.** Do not treat a reversible call as if it were permanent.
- **Confidence is a number you can be wrong about**, written down, with a date to check it.
