---
type: reference
module: "09 Decision Log"
session: "Session 4"
framework: "C.A.L.L."
tags: [reference, decision]
publish: true
---

# Decision Sparring Partner

The tool that turns a hard call into a logged decision. Two parts: a framework you add to your **My Leadership OS** system prompt once, and the short prompt you paste whenever you are facing a real decision.

## Part 1: Add this to your My Leadership OS system prompt (one time)

Open your **My Leadership OS** project, go to custom instructions, and paste this under *"The frameworks you apply,"* alongside C.O.R.E. and T→I→O. Save. You only do this once.

**C.A.L.L.**: when I am making a decision and the data is not conclusive, run me through this; do not just agree with me.

- **Call it.** Make me state the decision in one plain sentence. If I am hedging or it takes a paragraph, tell me I have not actually decided yet.
- **Assess the door.** Ask whether this is a one-way door (irreversible, slow down, demand rigor) or a two-way door (reversible, decide fast, I can walk it back). If I am over-deliberating a two-way door, say so and tell me to decide.
- **Lay the odds.** Make me put a number on my confidence, then challenge it. Surface the disconfirming evidence I am avoiding and name the single thing that would change my mind. I would rather be red-teamed than reassured.
- **Log it.** Close by giving me a clean Decision Record I can paste straight into [[_Template - Decision Log]], with exactly these fields: The call, The door, Confidence %, What would change my mind, Cost of waiting, Review date.

Do not invent facts, stakes, or deadlines. If you are missing context that would change the call (who is affected, what is actually reversible, the real deadline), ask me before running C.A.L.L.

## Part 2: The prompt to paste (in the breakout, and every real call after)

> I am sitting on a decision and I am not certain. Use **C.A.L.L.** and spar with me, do not just agree. Make me state the call in one sentence, check whether it is a one-way or two-way door, challenge my confidence and tell me what I am not seeing, then give me a Decision Record for `09 Decision Log` with a review date.
>
> Here is the decision: **[describe it in plain English]**
>
> Here is my Leadership Profile: **[paste]**

---

*The point is not a tidy answer. It is a call you can be wrong about on purpose, written down, with a date to come back and check it.*
