---
type: template
module: "03 Stakeholder Drafts"
session: "Session 1"
framework: "Influence Strategy Canvas"
status: template
stakeholder: 
strategy: 
tags: [template, influence, stakeholder-drafts]
publish: true
---

# Influence Plan: [Goal in one line]

> One file per influence goal. Not "get exec buy-in," something specific: pilot approval, roadmap shift, headcount, a green light to kill a project. Influence is how leaders move things without authority. Plan it like a system, not a hope.

Related: [[_Template - Audience Map]], [[_Template - Tension-Insight-Outcome]]

---

## The goal

- **What I am trying to move:** *(decision, resource, alignment, permission)*
- **By when:** 
- **Why now:** 

## The person

- **Name & role:** 
- **Audience Map:** *(link)*
- **What motivates them in this decision:** *(not their job description, the actual driver: career risk, a number they own, a peer they want to beat, a fear they will not say out loud)*

## The friction

*Where is the resistance? Be honest. Surface objection is rarely the real one.*

- **Surface objection:** 
- **Real objection (what is actually in the way):** 
- **What it would cost them to say yes:** 

## Strategy

*Pick the one that fits this person and this goal. Not all five. Influence by stacking is influence by spam.*

- [ ] **Data.** *Numbers they cannot argue with.*
- [ ] **Story.** *A T→I→O that makes the abstract concrete.*
- [ ] **Credibility.** *Borrow trust: a name, a precedent, an outside expert.*
- [ ] **Aligned goals.** *Reframe the ask in the language of what they already own.*
- [ ] **Social proof.** *Who else is already in. Peer pressure for grown-ups.*

**Why this one:** 

## First yes

*The smallest visible step you can take this week. Not the big ask. The micro-commitment that makes the big ask easier.*

- **The move:** 
- **By when:** 
- **What "yes" sounds like:** 

## The move (drafted)

*The actual message, opener, or 1:1 talking points that go out. In the audience's preferred format. In your voice. Strategy made into words.*

(<channel and format note, e.g. "Slack DM, two short paragraphs, no preamble.">)

<the polished version. Opens by acknowledging their world. Frames the ask in the language of what they own. Closes with the smallest possible yes.>

---

## Follow-up

- **What happened:** 
- **Next move:** 
- **What I learned about how to move this person:** *(feeds back into their Audience Map)*
