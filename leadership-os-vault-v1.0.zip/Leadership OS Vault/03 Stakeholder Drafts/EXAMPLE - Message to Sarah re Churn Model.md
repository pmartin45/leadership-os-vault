---
type: example
module: "03 Stakeholder Drafts"
session: "Session 1"
framework: "Influence Strategy Canvas"
status: active
stakeholder: Sarah (CMO)
strategy: Story
tags: [running-case, stakeholder-drafts, sarah, influence-plan]
publish: true
---

# Influence Plan: Two-week extension on the churn model (message to Sarah)

> Worked example. Influence Plan for the move that earns a two-week extension on the churn model, in exchange for a one-page retention story Sarah can take to the QBR. The Plan is the strategy. The message (under "The move") is the strategy turned into words.

Related: [[_Template - Influence Plan]], [[EXAMPLE - Sarah (CMO)]], [[EXAMPLE - T-I-O (Churn Retention)]]

---

## The goal

- **What I am trying to move:** Permission. A two-week extension on the churn model ship date, in exchange for a one-page retention story for the QBR.
- **By when:** End of this week (before Friday's planned ship).
- **Why now:** Sarah said "the data is wrong" in last week's leadership meeting. The longer I let that hang, the harder it gets to reopen the date. Closing the loop this week protects the model and the relationship.

## The person

- **Name & role:** Sarah, CMO.
- **Audience Map:** [[EXAMPLE - Sarah (CMO)]]
- **What motivates them in this decision:** Sarah owns the QBR narrative. Her real driver is not the churn model, it is walking into the board room with a retention story that holds together. "The data is wrong" was code for "I cannot defend this on Tuesday."

## The friction

- **Surface objection:** "The model is wrong."
- **Real objection (what is actually in the way):** The retention story is fragmented across three dashboards and she has no one-page version to take into the QBR. Shipping Friday locks the fragmentation in.
- **What it would cost her to say yes:** Two weeks of visible exposure (the model is late) without a guaranteed deliverable in hand. She needs proof the trade is worth it.

## Strategy

- [ ] **Data.** *Numbers alone do not move her, she already has three dashboards of them.*
- [ ] **Story.** *A T→I→O that makes the abstract concrete. Two segments, two bets, two owners, two numbers.*
- [ ] **Credibility.** *Not needed, I am the source.*
- [ ] **Aligned goals.** *Implicit in the framing, the ask is reframed in her language (QBR), not engineering's (model accuracy).*
- [ ] **Social proof.** *Not relevant, this is her call.*

**Why this one:** Sarah does not need more numbers, she needs a spine for the QBR. A T→I→O gives her exactly that, and reframes the two-week delay as the price of getting the story she actually needs. The story is worked out in [[EXAMPLE - T-I-O (Churn Retention)]].

## First yes

- **The move:** An email by tomorrow morning that opens with her own words, names the real tension, and ends with a question she has to answer (annual or monthly first).
- **By when:** Tomorrow, 9am.
- **What "yes" sounds like:** She replies picking a segment. That single reply is the micro-commitment. Once she has chosen, the extension is implicit.

## The move (drafted)

*Format: email, short, one screen. In her voice, opens with her words back at her.*

**Subject:** Churn model, why the extra two weeks, and what you get

Sarah,

You said last week the data was wrong. You are right that the story is not landing yet. Here is where we are and what I am choosing to do about it.

The retention narrative for the QBR is currently spread across three dashboards. Pushing the churn model live this Friday locks that fragmentation in.

What we found in the last sprint: annual and monthly contracts churn for fundamentally different reasons. Annual churns on price at renewal. Monthly churns on activation in the first 30 days. Modelling them as one segment was the gap you were picking up on.

Two extra weeks gets you one retention page for the QBR: two segments, two bets, two owners, two numbers. Decision, risk, ask, all on one screen.

One thing I need from you: which segment matters more for the board narrative, annual or monthly? That shapes which intervention we model first.

[Your name]

---

## Working notes

- Opens with her own words back to her. Earns the right to disagree.
- No methodology. She does not care that it is a logistic regression. She cares that the segments behave differently.
- Closes with a question she has to answer, not a status update. Keeps the loop open her way.
- Cut the original opener "I wanted to follow up on..." Her map says never open with that.

## Follow-up

- **What happened:** *(to fill in after sending)*
- **Next move:** *(what the reply unlocks)*
- **What I learned about how to move this person:** *(feeds back into [[EXAMPLE - Sarah (CMO)]])*
