---
type: readme
module: "03 Stakeholder Drafts"
session: "Session 1"
framework: "Influence Strategy Canvas"
tags: [readme, stakeholder-drafts, influence]
publish: true
---

# 03 Stakeholder Drafts

Where you plan how to move a specific person on a specific ask. One Influence Plan per goal: goal, person, friction, strategy, first yes, the actual move. The plan is the strategy. The message at the bottom is the strategy turned into words.

## What lives here

- **One Influence Plan per ask**: pilot approval, roadmap shift, headcount, permission to kill a project, a tough message that has to land. Each plan ends with the actual move, drafted, ready to send.
- **A worked example**: the influence plan for getting Sarah to greenlight a two-week extension on the churn model.

## How it grows

**Pre-work** builds the Sarah example. **Session 1** has you run [[00 Skills/03 - Influence Plan Skill|Influence Plan Builder]] on one real ask of your own and save the result here.

**After Session 1**: every non-trivial ask, every message that has to land with a specific person, gets an Influence Plan here first. Five minutes of planning, no wasted Slack threads.

## The rules

- **One goal per plan.** Not "get exec buy-in." Something specific you can hear "yes" or "no" to this week.
- **Name the real objection, not the surface one.** What it would actually cost them to say yes.
- **Pick one strategy, not five.** Influence by stacking is influence by spam.
- **The first yes is the smallest visible step.** Micro-commitment first, big ask second.
- **Link the Audience Map you built it from**, so the plan and the map stay connected.

## Produced by

- **[[00 Skills/03 - Influence Plan Skill|Influence Plan Builder skill]]**: walks you through goal, person, friction, strategy, first yes, then drafts the actual move. Saves the plan here and cross-links it into the audience map and (if any) the project.
