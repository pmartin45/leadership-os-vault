---
type: template
module: "08 Prioritization"
session: "Session 4"
framework: "Priority Grid"
status: template
week: 
tags: [template, prioritization]
publish: true
---

# Backlog Triage: [Week of ___]

> Duplicate this file, rename it to the week. Paste your raw backlog into [[_Reference - Prioritization Sparring Partner|the sparring partner]] in Claude, then drop the sorted result into the four moves below.

## Do, this week

High impact, low effort. The short list I actually protect time for.

-

## Sequence, into the rhythm

High impact, high effort. Roadmapped and resourced with a real slot, not squeezed into the gaps. (See [[_Template - Operating Rhythm]] in 07.)

-

## Delegate

Low impact, low effort. Someone else should own it. Name the person and the level. (See [[_Reference - 7 Levels of Delegation]] in 06.)

-

## Decline

Low impact, high effort. The defensible no. Note whether the C.O.R.E. message went out. (See 05 Change Communication.)

-

---

## Watch, loud but low-impact

The request I will be tempted to do anyway because of who is asking, not because it matters. Naming it is how I stop doing it.

-
