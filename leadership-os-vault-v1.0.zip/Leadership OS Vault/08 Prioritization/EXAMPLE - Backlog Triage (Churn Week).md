---
type: example
module: "08 Prioritization"
session: "Session 4"
framework: "Priority Grid"
status: active
tags: [running-case, prioritization]
publish: true
---

# Backlog Triage: Churn Week

> Worked example. Do not edit. Use it as a reference for sorting your own backlog.

## Do, this week

High impact, low effort. The short list I actually protect time for.

- Send Priya the one-slide pilot result (€146K recovered, roughly 14x on €8K). Unblocks the rollout decision.
- 1:1 with Marcus to scope the pipeline work.

## Sequence, into the rhythm

High impact, high effort. Roadmapped with a real slot, not squeezed in.

- Full rollout across every segment. Funded at €90K, live by Q3. Goes in the [[EXAMPLE - Operating Rhythm (Churn Team)|rhythm]] as a monthly ROI check with Priya.

## Delegate

Low impact, low effort. Someone else should own it, at the right level.

- Week-one validation. Daniel owns it at Level 5, Advise. See [[EXAMPLE - Daniel - Churn Validation]].

## Decline

Low impact, high effort. The defensible no.

- The cross-team "AI showcase" deck a VP asked for. High effort, no metric behind it. Decline with a C.O.R.E. message.

---

## Watch, loud but low-impact

- The showcase deck. The VP asking is senior, so I will be tempted to do it anyway. Naming it here is how I stop. It moves no number I am measured on.
