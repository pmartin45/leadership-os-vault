---
type: readme
module: "08 Prioritization"
session: "Session 4"
framework: "Priority Grid"
tags: [readme, prioritization]
publish: true
---

# 08 Prioritization

Where an overloaded backlog becomes a defensible plan. The Priority Grid sorts the work; RICE breaks the ties.

## What lives here

- **A Backlog Triage note for any week the list is bigger than the week.** Every request sorted into Do, Sequence, Delegate, or Decline.
- **The Prioritization Sparring Partner**: the framework you add to your Claude Project once, plus the prompt you paste to sort a backlog.
- **A worked example** built on the running case.

## How it grows

**Session 4** teaches the grid and RICE. Add the sparring partner to your system prompt once, then duplicate `_Template - Backlog Triage.md` whenever you are overloaded.

**After Session 4**: triage on demand, every week the work outruns the time.

## Produced by

- **[[00 Skills/08 - Backlog Triage Skill|Backlog Triage skill]]**: the fastest way to triage a week's backlog. Captures your list (plus due-soon items it spots in the vault), asks one short framework-aligned question set per item, writes the result as `W## YYYY - Backlog Triage.md` in this folder.

## The rules

- **Score the work, then read the room.** Use your Audience Maps. The loudest request is often the lowest-impact one.
- **Sequence is a real slot, not a someday.** Put it in the rhythm.
- **A Decline goes out with a C.O.R.E. message**, so the no does not cost the relationship.
