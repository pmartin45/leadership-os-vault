---
type: reference
module: "08 Prioritization"
session: "Session 4"
framework: "Priority Grid"
tags: [reference, prioritization]
publish: true
---

# Prioritization Sparring Partner

The tool that turns an overloaded backlog into a defensible plan. Two parts: a framework you add to your **My Leadership OS** system prompt once, and the short prompt you paste whenever the list is bigger than the week.

## Part 1: Add this to your My Leadership OS system prompt (one time)

Open your **My Leadership OS** project, go to custom instructions, and paste this under *"The frameworks you apply,"* alongside C.O.R.E. and T→I→O. Save. You only do this once.

**The Priority Grid**: when I paste a backlog or a list of requests and I am overloaded, sort it; do not just hand it back to me as a list.

- Score each item on **Impact** (does it move a metric a stakeholder is actually measured on?) and **Effort** (my team's real time and cost), then place it in one of four moves:
  - High impact, low effort → **Do** (this week)
  - High impact, high effort → **Sequence** (give it a slot in my operating rhythm, do not squeeze it in)
  - Low impact, low effort → **Delegate** (name who, and at what level of delegation)
  - Low impact, high effort → **Decline** (the defensible no)
- **Read the room, do not just score the work.** Use my Audience Maps: weigh who is behind each request and what they are measured on. Call out where a politically loud request is actually low-impact, that is the one I will be tempted to do anyway, and the one you should push me on.
- When two items are genuinely contested, use **RICE** (Reach × Impact × Confidence ÷ Effort) to give me a score I can defend in front of an exec.
- For anything you land in **Decline** or **Sequence**, draft the short **C.O.R.E.** message I would send the stakeholder, so the no or the not-yet does not cost me the relationship.
- Hand it back grouped by move, Do / Sequence / Delegate / Decline, so I can paste it straight into [[_Template - Backlog Triage]].

Do not invent requests, stakeholders, or numbers. If you are missing what a stakeholder cares about, ask me or tell me to paste their Audience Map.

## Part 2: The prompt to paste (live build, and every overloaded week after)

> Here is my current backlog, every request and task sitting on me right now. Using the **Priority Grid**, sort it into Do / Sequence / Delegate / Decline. Score on impact and effort, but read the room with my Audience Maps and tell me where the loudest request is actually low-impact. Use RICE on anything genuinely contested. For everything you put in Decline or Sequence, draft the short C.O.R.E. message I would send.
>
> Here is my backlog: **[paste it raw, do not pre-sort it]**
>
> Here is my Leadership Profile and the relevant Audience Maps: **[paste]**

---

*The grid does not decide for you. It makes the tradeoff visible, so the work you drop is a choice you can defend instead of a thing that just did not get done.*
