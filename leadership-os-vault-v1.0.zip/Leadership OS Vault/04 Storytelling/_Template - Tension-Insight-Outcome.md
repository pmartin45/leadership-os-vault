---
type: template
module: "04 Storytelling"
session: "Session 1"
framework: "T→I→O"
status: template
theme: 
tags: [template, storytelling]
publish: true
---

# T → I → O: [Topic]

> The spine of every executive message. Tension names the friction. Insight reframes it. Outcome makes it concrete.

## Context

- **Audience:** *(link to their audience map)*
- **The change I need to land:** *(one sentence, what is different after they read this?)*
- **The format this becomes:** *(email / 1-pager / 3-slide / verbal)*

## Tension

*The friction. What is not working, what is unresolved, what is at stake right now. Name it directly. Soft tension makes a soft message.*

- 

## Insight

*The non-obvious thing you are seeing that they are not. The reframe. "Here is what is actually happening underneath," not a recap of the tension.*

- 

## Outcome

*The specific, concrete change that follows from the insight. A decision, a number, a risk owned, a next step with a name on it. If you cannot picture what changes Monday morning, the outcome is not sharp enough.*

- 

## Why it matters

*One line, business or human. The reason this story is worth telling at all. If you cannot answer this, it is not a story yet, it is a recap.*

- 

## Story Bank

*Tag the theme in the frontmatter (`theme:`): Leadership, Impact, AI, Change, Collaboration, or your own. The vault becomes a searchable library you can pull from for talks, updates, retros, and interviews.*

## The draft

*(Write the actual message here. The T→I→O spine should be visible in the structure even if the words do not appear.)*

---

## Working notes

- 
