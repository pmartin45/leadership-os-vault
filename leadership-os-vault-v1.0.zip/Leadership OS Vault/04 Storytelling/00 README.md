---
type: readme
module: "04 Storytelling"
session: "Session 1"
framework: "T→I→O"
tags: [readme, storytelling]
publish: true
---

# 04 Storytelling

Where you sharpen the spine that runs through every executive message: Tension → Insight → Outcome.

## What lives here

- **A T→I→O note for any message, deck, or update that has to move someone.** Tension names the friction. Insight reframes it. Outcome makes it concrete.
- **A worked example** built on the churn retention story.

## How it grows

**Session 1** teaches T→I→O on the Sarah churn case. Duplicate `_Template - Tension-Insight-Outcome.md` whenever a message is not landing and you need to find its spine.

**After Session 1**: use it any time the stakes are high enough that the structure has to be right before the words.

## The rules

- **Soft tension, soft message.** Name the friction directly.
- **Insight is a reframe, not a recap.** Say what they are not seeing.
- **If you cannot picture what changes Monday morning, the outcome is not sharp enough.**

## Produced by

- **[[00 Skills/04 - Storytelling Skill|Storytelling (T→I→O) skill]]**: locks the audience and the change you want to land, builds the T→I→O spine, then drafts the actual message in the format the audience consumes. Saves it here.
