---
type: example
module: "04 Storytelling"
session: "Session 1"
framework: "T→I→O"
status: active
tags: [running-case, storytelling, sarah]
publish: true
---

# T → I → O: Churn Retention

> Worked example. Do not edit. Use it as a reference for finding the spine of your own message.

## Context

- **Audience:** [[EXAMPLE - Sarah (CMO)]]
- **The change I need to land:** Sarah backs the retention play in the QBR and funds it from existing budget.
- **The format this becomes:** A one-page message. See [[EXAMPLE - Message to Sarah re Churn Model]].

## Tension

The retention story for the QBR is fragmented across three dashboards, and nobody owns the number. Sarah is being asked where the leaky bucket is, and she does not have a clean answer.

## Insight

About 1,800 accounts are flagged at-risk in the next 90 days, and the model spots them roughly three weeks earlier than we catch them today. Those three weeks are the difference between a save and a goodbye. This is not a modelling story, it is a timing story.

## Outcome

Run the retention play on the at-risk list. It holds roughly one in five of them, funded from existing budget, no new spend. One number for the QBR, one owner, one bet.

## The draft

The full message built from this spine lives in [[EXAMPLE - Message to Sarah re Churn Model]]. The T→I→O structure is visible in the draft even though the words "tension" and "insight" never appear.

---

## Working notes

- Cut every reference to the model internals. Sarah's map says methodology makes her shut down.
- The "three weeks earlier" line is the whole insight. Lead with timing, not accuracy.
