---
type: reference
module: "06 Delegation Briefs"
session: "Session 3"
framework: "7 Levels of Delegation"
tags: [reference, delegation]
publish: true
---
# The Seven Levels of Delegation: A Detailed Reference

A complete working reference for the Seven Levels of Delegation framework. Written to be used as source knowledge for a skill that produces documents, briefs, coaching prompts, or training material. Each level is broken down the same way so the content is easy to parse and reuse.

---

## 1. What the framework is

Delegation is usually treated as a switch: either you do the work or you hand it off. The Seven Levels of Delegation replaces that switch with a dial. The same task can be delegated seven different ways, and the only question each setting answers is: **who makes the decision, and how much does the manager stay involved?**

The framework comes from Jurgen Appelo's Management 3.0 work (first published around 2011). It is widely used in agile, product, and data-team contexts because it gives managers a precise, shared vocabulary for authority instead of vague phrases like "own it" or "keep me in the loop."

The seven levels run from full manager control to full team control:

```
YOU HOLD CONTROL  <-----------------------------------------> THEY HOLD CONTROL
   1        2         3          4          5         6            7
  TELL     SELL    CONSULT     AGREE      ADVISE   INQUIRE     DELEGATE
                                                                  FULLY
```

The levels are not a ranking of good to bad. Level 1 is not "worse" than Level 7. Each level is correct in the right context. The skill is matching the level to the situation.

### Three things the framework is built on

1. **Authority is a spectrum, not a binary.** Between "I decide" and "you decide" there are five useful middle settings. Most real delegation lives in the middle.
2. **Delegation is per decision area, not per person.** The same person can be at Level 2 for budget decisions and Level 6 for tooling decisions. You delegate decisions, not people.
3. **The level should be explicit and shared.** Most delegation friction comes from the manager and the team member silently assuming different levels. Naming the level removes that gap.

---

## 2. The control spectrum at a glance

|Level|Name|Who decides|Manager involvement|The move in one line|
|---|---|---|---|---|
|1|Tell|Manager|Total. Manager decides and directs.|"Here is what to do."|
|2|Sell|Manager|High. Manager decides and explains why.|"Here is what to do, and why."|
|3|Consult|Manager|High. Manager gathers input, then decides.|"Give me your input, then I decide."|
|4|Agree|Both, jointly|Shared. Decision is made together.|"We decide together."|
|5|Advise|Team member|Moderate. Manager offers a view, person decides.|"Here is my advice, but you call it."|
|6|Inquire|Team member|Low. Person decides, then informs manager.|"You decide, then tell me what you did."|
|7|Delegate Fully|Team member|None required. Person owns it end to end.|"It is yours. I do not need to be in it."|

A useful mental model: as you move from 1 to 7, **information and control flow from the manager to the team member**. At the low end the manager pushes instructions out. At the high end the team member pulls authority in and pushes results back only if and when they choose.

---

## 3. Core principles before you pick a level

These principles sit above the individual levels and shape every choice.

### Match the level to readiness and risk, not to your nerves

The single most common mistake is delegating one level **too low** to feel safe. To a capable person, a level that sits below their actual ability quietly reads as "I do not trust you yet." It caps their growth and signals doubt. The level should reflect how ready the person is and how much is at stake, not how anxious the manager feels.

### Readiness and stakes are the two main dials

- **Readiness:** how proven the person is on this specific kind of work. Not their seniority in general, but their track record on this decision area.
- **Stakes:** how costly a mistake would be, and how reversible it is. High stakes plus low reversibility pulls the level down. Low stakes plus easy reversibility pushes it up.

### Delegation is a path, not a one-time act

Naming the current level is only half the job. The other half is naming the next level up and roughly when you expect to move there. Delegation done well is a deliberate progression: the person earns higher levels as they prove readiness, and the manager plans the handoff rather than waiting for it to happen by accident.

### Responsibility without authority is a trap

If you give someone responsibility for an outcome but keep the real decision authority for yourself, you have not delegated. You have set them up to be accountable for choices they cannot make. Each level should pair the responsibility with the matching authority and the information needed to use it.

### Delegation is not abdication

The opposite failure is handing something off and disappearing. Even at Level 7, the manager remains accountable for the result at the organisational level. Delegating the decision does not delegate away your duty to set context, define boundaries, and make sure the person is set up to succeed.

---

## 4. The seven levels in detail

Every level below is described with the same structure: definition, control balance, what it looks like, what it entails for each side, example phrasing, when to use it, pros, cons, pitfalls, and the signals that tell you the level is wrong. A single running example (a team member building a revenue dashboard in a BI tool) is used throughout so the levels can be compared directly.

---

### Level 1: Tell

**Definition.** The manager makes the decision and tells the team member exactly what to do. The team member executes the instruction. No input is sought and none is expected.

**Control balance.** Manager: total. Team member: none on the decision, full on the doing.

**What it looks like.** Clear, specific instructions with a defined output and deadline. The manager has already decided the what, the how, and the when. The team member's job is to carry it out accurately.

**What it entails.**

- For the manager: full clarity on the desired output, the steps, and the standard. The manager owns the thinking and the outcome.
- For the team member: faithful execution. Success is doing exactly what was asked, well and on time.

**Example phrasing.** "Build these three views in the BI tool and send me the dashboard by Friday."

**When to use it.**

- The work is brand new to the person and they have no basis yet for judgment.
- The stakes leave no room to learn on the job (compliance, safety, a hard external deadline).
- A crisis where speed and certainty matter more than development.
- Onboarding, where clear instructions reduce anxiety.

**Pros.**

- Fast and unambiguous.
- Low risk when correctly applied to genuinely new or high-stakes work.
- Gives a beginner a clear, safe starting point.

**Cons.**

- Uses none of the person's judgment.
- Does not develop the person.
- Does not scale: every decision routes back through the manager.

**Pitfalls.**

- Using it as a default because it feels safe, long after the person is ready for more.
- Disguising it as a higher level ("what do you think?") while having already decided, which breeds cynicism.
- Telling without explaining context, so the person cannot adapt if reality differs from the instruction.

**Signals the level is wrong.** A capable person goes quiet, stops offering ideas, or starts asking permission for trivial things. That is Level 1 applied to someone who has outgrown it.

---

### Level 2: Sell

**Definition.** The manager still makes the decision, but takes the time to explain the reasoning and persuade the team member to buy in. The goal is commitment, not just compliance.

**Control balance.** Manager: high. Team member: none on the decision, but invited to understand and endorse it.

**What it looks like.** The manager states the decision and then walks through the why: why it matters, why now, and often why this person. The conversation is one-directional on the decision itself but two-directional on understanding.

**What it entails.**

- For the manager: a clear rationale and the willingness to spend energy on persuasion rather than just issuing an order.
- For the team member: engaging with the reasoning, asking clarifying questions, and committing rather than merely obeying.

**Example phrasing.** "I want you building this dashboard. Here is why it matters, and why it is you."

**When to use it.**

- You need genuine commitment, not grudging compliance.
- The decision is yours, but the person's motivation and buy-in materially affect the result.
- A change or direction that the person may resist or not yet understand.

**Pros.**

- Builds ownership and morale even though the decision is the manager's.
- The person executes with more energy and adapts more intelligently because they understand the intent.
- Strengthens trust by treating the person as someone worth persuading.

**Cons.**

- Slower than Tell.
- Still does not hand over any real decision authority.
- Can tip into manipulation if the "selling" is spin rather than honest reasoning.

**Pitfalls.**

- Fake selling: pretending to seek buy-in when the manager will not accept disagreement.
- Over-selling a weak decision, where energy spent on persuasion would be better spent rethinking the decision.
- Treating Sell as a permanent setting for someone who is ready to help shape decisions.

**Signals the level is wrong.** The person keeps offering alternatives the manager will not consider, or visibly disengages from a decision they could help improve. They are ready for Consult or higher.

---

### Level 3: Consult

**Definition.** The manager asks for the team member's input before deciding, then makes the decision. Their perspective informs the call, but the call remains the manager's.

**Control balance.** Manager: holds the decision. Team member: real influence, no final authority.

**What it looks like.** A genuine ask for input ("what are you seeing?", "what would you do?") followed by the manager weighing that input and deciding. The person's read is treated as valuable signal, not a formality.

**What it entails.**

- For the manager: asking honestly, listening, and being prepared to be influenced. Then deciding and, ideally, explaining how the input shaped the decision.
- For the team member: thinking the problem through and offering a real recommendation, while accepting that the final call sits with the manager.

**Example phrasing.** "Before I lock the metrics, what would you put on the main dashboard view?"

**When to use it.**

- The person's closeness to the work sharpens a call that is still the manager's to make.
- The manager wants to develop the person's judgment without yet transferring authority.
- Decisions where the manager has the broader context but the person has the detail.

**Pros.**

- Better decisions, because they draw on the person closest to the work.
- Develops judgment safely: the person practises deciding without owning the risk.
- Signals respect and builds the relationship.

**Cons.**

- Slower than deciding alone.
- Can frustrate the person if their input is repeatedly ignored without explanation.
- Still concentrates final authority in the manager.

**Pitfalls.**

- Consultation theatre: asking for input after the decision is effectively made.
- Soliciting input and then never closing the loop on how it was used, which trains people to stop contributing.
- Using Consult to avoid the discomfort of either deciding (Tell) or letting go (Advise).

**Signals the level is wrong.** The person's input is consistently right and consistently adopted. At that point keeping the final call is just delay; they are ready for Agree or Advise.

---

### Level 4: Agree

**Definition.** The manager and the team member make the decision together, as equals. Neither side can decide unilaterally; the outcome is a genuine joint commitment.

**Control balance.** Shared, fifty-fifty. Both parties own the decision.

**What it looks like.** A real discussion aimed at a shared conclusion. Both parties bring their views, work through differences, and arrive at a decision both can stand behind. It is consensus, not negotiation by authority.

**What it entails.**

- For the manager: setting aside positional authority and engaging as a peer. Willingness to be talked out of a preference.
- For the team member: bringing a real position, defending it, and co-owning the result rather than deferring.

**Example phrasing.** "Let us settle the dashboard layout together and commit to it."

**When to use it.**

- Both parties genuinely own the outcome and both must be committed for it to work.
- Cross-functional or peer-level decisions where shared ownership matters more than speed.
- Building a shared standard or working agreement that both will rely on.

**Pros.**

- Strongest shared ownership of any level.
- Combines two perspectives into a better, more durable decision.
- Builds the relationship into a genuine partnership.

**Cons.**

- The slowest level. Reaching real agreement takes time.
- Can deadlock if the two parties cannot align.
- Blurs accountability if it is unclear who follows through.

**Pitfalls.**

- Fake equality: the manager calls it Agree but pulls rank the moment there is disagreement.
- Using Agree to avoid making a hard call, hiding behind "we decided together."
- Endless consensus-seeking on decisions that did not need both parties.

**Signals the level is wrong.** One party is clearly carrying the decision while the other defers. If the person should simply own it, move to Advise or higher. If the manager should own it, move back to Consult.

---

### Level 5: Advise

**Definition.** The team member makes the decision. The manager offers their view as input, but the call belongs to the person. This is the first level where decision authority crosses to the team member.

**Control balance.** Team member: holds the decision. Manager: a voice, not a vote.

**What it looks like.** The manager shares one clear piece of advice and then explicitly hands the decision over. The person weighs the advice alongside everything else and decides. They are free to act against the advice.

**What it entails.**

- For the manager: offering a perspective without strings, then genuinely stepping back. Resisting the urge to overrule.
- For the team member: owning the decision, including the consequences. Treating the advice as one input among several.

**Example phrasing.** "You pick the metrics and the layout. Here is my one piece of advice, but it is your call."

**When to use it.**

- The person is capable and you are actively growing them.
- You want their judgment to be the point, while staying available as a sounding board.
- Decisions where your experience is useful but not decisive.

**Pros.**

- Develops decision-making while keeping a safety net.
- Frees the manager from being the bottleneck while staying connected.
- Strong signal of trust, which motivates capable people.

**Cons.**

- The manager has to tolerate decisions they would have made differently.
- Mistakes will happen and must be allowed as part of growth.
- Requires the manager to give advice cleanly without it landing as an instruction.

**Pitfalls.**

- Advice that is really a command in disguise ("it is your call, but I would be very unhappy if you chose anything else").
- Overruling after the fact, which destroys the trust the level was meant to build.
- Flooding the person with advice until the decision is effectively the manager's again.

**Signals the level is wrong.** The person rarely needs the advice and consistently decides well without it. They are ready for Inquire. Conversely, if they are clearly struggling and the stakes are high, step back to Consult or Agree rather than letting them sink.

---

### Level 6: Inquire

**Definition.** The team member decides and acts on their own, then informs the manager afterward. The manager learns what happened after the fact, not before.

**Control balance.** Team member: full decision and action authority. Manager: informed, not consulted.

**What it looks like.** The person handles the work their own way and reports the outcome. The manager's role is to stay aware, not to approve. The report is a courtesy and a feedback channel, not a checkpoint.

**What it entails.**

- For the manager: trusting the person to act and being content to hear about it afterward. Using the report to coach, not to second-guess.
- For the team member: acting with full ownership and proactively keeping the manager informed.

**Example phrasing.** "Build the dashboard your way, then tell me what you decided."

**When to use it.**

- The person is proven on this kind of work and the stakes are moderate.
- You want to free your own time while keeping visibility.
- The person needs autonomy but the organisation still benefits from awareness.

**Pros.**

- Gives the manager time back while keeping a line of sight.
- High autonomy motivates proven people.
- Scales: decisions stop routing through the manager.

**Cons.**

- The manager finds out about problems only after they have occurred.
- Requires real trust; hard to apply to genuinely high-stakes, irreversible work.
- Depends on the person reliably reporting back.

**Pitfalls.**

- Turning the "tell me after" into a disguised approval gate (reacting as if you should have been asked first).
- The person stops reporting, and visibility quietly erodes.
- Applying Inquire to work where a surprise after the fact would be too costly.

**Signals the level is wrong.** You find yourself wishing you had been consulted before the fact on these decisions: the stakes have risen and Advise or Consult may fit better. If the after-the-fact reports add no value and feel like overhead, the person is ready for Level 7.

---

### Level 7: Delegate Fully

**Definition.** The team member owns the decision and the work completely. No reporting back is required. The work is genuinely theirs.

**Control balance.** Team member: total. Manager: out of it unless invited.

**What it looks like.** The person runs the work end to end and the manager does not need to be involved at all. The manager remains accountable at the organisational level but does not participate in the decisions. If the person wants a sounding board, they come and get one.

**What it entails.**

- For the manager: complete trust, clear boundaries set up front, and genuine non-involvement. The manager stays accountable for outcomes without controlling them.
- For the team member: full ownership of the work, the decisions, and the results.

**Example phrasing.** "The dashboard is yours. I do not need to be in it unless you want me."

**When to use it.**

- The person is trusted and proven on this work, and the work is genuinely theirs to own.
- You want to fully free your own time and let the person operate at their level.
- Mature, capable people for whom any involvement would be friction.

**Pros.**

- Maximum autonomy and maximum scale.
- Frees the manager entirely for higher-leverage work.
- Strongest possible signal of trust and respect.

**Cons.**

- No visibility unless the person volunteers it.
- A poor fit when stakes are high or the person is not genuinely ready.
- The manager still carries organisational accountability without day-to-day insight.

**Pitfalls.**

- Confusing Level 7 with abdication: handing it over with no boundaries, no context, and no support, then blaming the person when it goes wrong.
- Jumping straight to Level 7 to avoid the work of developing someone through the lower levels.
- Quietly clawing the work back at the first stumble, which teaches the person that "fully yours" was never true.

**Signals the level is wrong.** If you feel a recurring need to know what is happening, the stakes have changed and the level should drop. If the person is thriving and would benefit from more scope, the answer is more Level 7 work, not less autonomy on this one.

---

## 5. How to choose the right level

Choosing a level is a judgment call, but it is a structured one. Run through these factors.

**Readiness on this specific work.** How proven is the person on this exact kind of decision? Track record beats job title. A senior person can be at Level 2 on something genuinely new to them.

**Stakes and reversibility.** How bad is a wrong call, and how easily can it be undone? High cost plus low reversibility pulls the level down. Low cost plus easy reversibility pushes it up.

**Urgency.** A true emergency can justify a temporary drop to Tell. But urgency is often used as an excuse to under-delegate out of habit, so check whether the urgency is real.

**Learning goal.** If the explicit aim is to grow the person, deliberately choose a level slightly higher than pure risk management would suggest, and provide a safety net. Growth requires controlled exposure to real decisions.

**Motivation and buy-in.** When commitment matters as much as the decision itself, Sell, Consult, or Agree earn their extra time by producing ownership.

**Your own capacity.** If you are the bottleneck and the person is ready, raising the level is not a luxury; it is how the system scales.

### A short decision check before any handoff

1. **Is this even mine to keep?** If the decision does not need to sit with you, it belongs off your plate, not held.
2. **How ready are they, really?** Their readiness sets the level, not your nerves.
3. **Which level next, and by when?** Name the move up front. Delegation is a path, so state where it leads.

---

## 6. The same task moves up the dial over time

A single task handed to one person can sit at different levels at different times. The work does not change; the level does. This is the core of using the framework for development.

Example, one person, one task (validating or building the revenue dashboard), three points in time:

- **Earlier (Level 1, Tell):** "Build these views and send me the dashboard." The person waits to be told. Their judgment sits unused.
- **Now (Level 5, Advise):** "You call the metrics. I am a sounding board." The person decides. Their judgment is the point.
- **Later (Level 7, Delegate Fully):** "The dashboard is yours, end to end." The person owns it. The manager gets the time back.

The level you choose decides whether the person grows or waits. Moving up the dial deliberately, and telling the person you are doing it, is what turns delegation into development.

**Moving down the dial** is rarer and should be handled carefully. Legitimate reasons include a genuine change in stakes, a new and unfamiliar context, or a clear pattern of the work going wrong. Dropping a level as a punishment, or out of recovered anxiety, damages trust. If you must move down, say why and name the path back up.

---

## 7. Team tools that use the framework

The seven levels also power two well-known team practices.

### The Delegation Board

A visible board (physical or digital) with the seven levels as columns and the team's key decision areas as rows. For each decision area, the team marks which level currently applies. This makes implicit authority explicit: everyone can see who decides what and at which level. It is a living artifact, updated as people grow and as decision areas change. Its main value is removing the silent mismatches where a manager thinks something is delegated and the team thinks it is not, or the reverse.

### Delegation Poker

A short, gamified alignment exercise. For a given decision area, each person privately picks a card from 1 to 7 representing the level they think applies, then everyone reveals at once. Where the cards disagree, the group discusses why. The point is not to vote on the "right" level but to surface and resolve mismatched expectations through conversation. It is most useful when a team is setting up or revising a Delegation Board.

---

## 8. Pitfalls across the whole framework

Failure modes that apply regardless of level:

- **Delegating one level too low to feel safe.** The most common mistake. To a capable person it reads as distrust and caps their growth.
- **Treating delegation as all-or-nothing.** Ignoring the five middle settings and bouncing between Tell and Delegate Fully.
- **Responsibility without authority.** Holding someone accountable for outcomes while keeping the decisions for yourself.
- **Abdication dressed as delegation.** Handing work over with no context, boundaries, or support, then blaming the person.
- **Silent level mismatch.** Manager and team member assume different levels and never name it, producing repeated friction.
- **Inconsistency.** Changing the level without telling anyone, so people cannot tell whether a decision is theirs.
- **Fake higher levels.** "Consult" that is really Tell, "Agree" that collapses to the manager's preference, "Advise" that is a veiled command. These are worse than honestly using the lower level, because they erode trust.
- **Overruling after the fact.** Granting authority at Level 5 or 6 and then reversing the person's decisions, which teaches them the authority was never real.
- **Upward delegation.** Letting the person hand decisions back up that they were equipped to make, often because the manager solves it faster. This quietly pulls the level back down.
- **Delegating the task but not the information.** Giving authority without the context, access, or data needed to use it well.

---

## 9. Quick application

To put the framework to work on a real task:

1. Pick one task that is eating your week.
2. Find the level you are on now.
3. Name the next level up.
4. Write that handoff today, in the words you would actually use.
5. Put a date on moving to the level after it.

The goal is not to delegate everything. The goal is to never leave someone a level below where they are ready to stand.

---

## 10. Glossary and one-line definitions

- **Tell (1):** You decide, they execute.
- **Sell (2):** You decide, you explain why.
- **Consult (3):** You ask, then you decide.
- **Agree (4):** You both decide, as equals.
- **Advise (5):** They decide, you advise.
- **Inquire (6):** They act, they tell you after.
- **Delegate Fully (7):** They own it completely.
- **Key decision area:** A specific category of decisions (for example, tooling, budget, hiring) that gets its own delegation level. You delegate decision areas, not whole people.
- **Delegation Board:** A visible map of which level applies to each key decision area for the team.
- **Delegation Poker:** A reveal-and-discuss exercise for aligning on the level that applies to a decision area.
- **Readiness:** How proven a person is on a specific kind of work. The primary input to choosing a level.
- **Stakes:** The cost and reversibility of a wrong call. The other primary input to choosing a level.

---

## Source note

This reference reflects the Seven Levels of Delegation as originated by Jurgen Appelo in Management 3.0, using the standard level names (Tell, Sell, Consult, Agree, Advise, Inquire, Delegate), with Level 7 labelled "Delegate Fully" for clarity. The practical framing (match the level to readiness not nerves, the pre-handoff check, the same-task-over-time progression) is consistent with how the framework is commonly taught and applied. If you want this verified or expanded against specific published sources, enable web search and I can cross-check the details and add citations.