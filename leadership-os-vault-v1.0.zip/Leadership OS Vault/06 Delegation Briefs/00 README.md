---
type: readme
module: "06 Delegation Briefs"
session: "Session 3"
framework: "7 Levels of Delegation"
tags: [readme, delegation]
publish: true
---

# 06 Delegation Briefs

This is where you stop being the bottleneck. One brief per task you hand off, each one naming the level you are delegating at, out loud, on purpose.

## What lives here

- **A Delegation Brief for each task you hand off.** The task, the owner, the level you are at now and the level you are aiming for, what "done" means, what they can decide without you, and when you check back in.
- **A Reference note**, [[_Reference - 7 Levels of Delegation]], so you can name the level instead of guessing it.
- **A Bases view**, `Delegation.base`, that surfaces every brief in this folder for quick scanning.

## How it grows

**Session 3, Breakout 2** builds the first one. Duplicate `_Template - Delegation Brief.md`, rename it after the task, and fill it in with a real person and a real handoff.

**After Session 3**: every task you delegate earns its own brief. Same shape, every time. That is the system that lets the team carry more without you carrying them.

## The rules

- **Name the level out loud.** A brief that does not state a level (1 to 7) is not a brief, it is a wish.
- **Real tasks, real owners.** Not "the team should own more." *"Daniel owns churn-model validation"* does.
- **Always set the step-up.** Every brief names the level you are aiming for next and the date you will revisit it. Delegation that never moves is just a job description.
- **Write what is safe to decide without you.** If you cannot name the guardrails, you are not delegating, you are waiting to be asked.

## Produced by

- **[[00 Skills/06 - Delegation Brief Skill|Delegation Brief skill]]**: walks you through person, project, task, readiness, level, and guardrails, then writes three artifacts in one pass: a Delegation Brief here, a delegation entry on the audience map, and a delegation entry on the matched project. Every line traces back to [[_Reference - 7 Levels of Delegation]].
