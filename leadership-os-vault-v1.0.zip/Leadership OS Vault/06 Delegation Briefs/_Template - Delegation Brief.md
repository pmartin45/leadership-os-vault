---
type: template
module: "06 Delegation Briefs"
session: "Session 3"
framework: "7 Levels of Delegation"
status: template
owner: 
level_now: 
level_target: 
tags: [template, delegation]
publish: true
---

# Delegation Brief: [Task]

> Duplicate this file, rename it to the task, fill it in. One brief per handoff.

## The handoff

- **Task:** *(what you are handing off, one line)*
- **Owner:** *(name and role)*

## The level

- **Level now:** *(1 to 7)*, *([level name]: one line on what that sounds like in practice)*
- **Aiming for:** *(1 to 7)*, *([level name]: where this person gets to next, and roughly when)*

See [[_Reference - 7 Levels of Delegation]] if you are not sure which rung you are on.

## The guardrails

- **What "done" looks like:** *(the finish line, concrete enough that they will know when they have crossed it)*
- **Safe to decide without me:** *(the explicit guardrails, the range they can move in without checking)*
- **What I need back and when:** *(the one thing you want, and the moment you want it)*

## The step-up

- **Step-up review date:** *(when you revisit the level and decide whether to raise it)*

## Notes

*(Context that does not fit above. What you are nervous about handing over. What raising the level would take.)*

-
