---
type: example
module: "06 Delegation Briefs"
session: "Session 3"
framework: "7 Levels of Delegation"
status: active
owner: Daniel
level_now: 5
level_target: 7
tags: [running-case, delegation, daniel]
publish: true
---

# Delegation Brief: Churn-Model Validation

> Worked example. Do not edit. Use it as a reference for writing your own.

## The handoff

- **Task:** Own churn-model validation.
- **Owner:** Daniel (Senior Analyst), who built the model.

## The level

- **Level now:** 5, Advise. *"You set the thresholds; advise me before you ship."* I still see it before it goes out, but the call is his.
- **Aiming for:** 7, Delegate Fully. *"Owns validation end-to-end."* Target: next quarter. He stops running it past me; it is just his.

See [[_Reference - 7 Levels of Delegation]].

## The guardrails

- **What "done" looks like:** Thresholds set, sign-off note shipped.
- **Safe to decide without me:** Adjust thresholds within plus or minus 2 points without me. Anything wider, flag it first.
- **What I need back and when:** A one-line heads-up before ship. Not a report, a sentence.

## The step-up

- **Step-up review date:** End of quarter.

## Notes

- This is the unlock for Daniel. He is strong technically but I keep covering for him cross-functionally, which makes me the bottleneck and stops him growing. Putting his name on validation, and saying so to [[EXAMPLE - Sarah (CMO)|Sarah]] and Priya, is the point.
- Moving him from 5 to 7 means resisting the urge to "just check the thresholds myself." The plus or minus 2 band exists so I do not have to.
- Raising the level depends on one thing: does the Friday sign-off note land cleanly without me editing it? If yes, he is ready for 6 → 7.
