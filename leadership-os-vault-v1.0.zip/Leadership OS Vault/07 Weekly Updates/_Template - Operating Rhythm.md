---
type: template
module: "07 Weekly Updates"
session: "Session 3"
framework: "Operating Rhythm"
status: template
tags: [template, operating-rhythm]
publish: true
---

# Operating Rhythm

> Duplicate this file once, design your rhythm, then let it run. Revisit it when the shape of your week changes, not every week.

> [!quote]
> Leaders design systems. They do not just do more.

## The three layers

Give every recurring commitment a layer and a job. The job comes from the **Meeting Map**: Align, Decide, or Learn. Anything that is none of those is Noise wearing a calendar invite. Cut it.

### Personal

*(Your own focus and thinking time. What you protect for yourself, and when.)*

| Cadence | Commitment | Job (Align / Decide / Learn) |
|---|---|---|
|  |  |  |

### Team

*(1:1s, standups, reviews. The rhythm that keeps the team moving without you in every loop.)*

| Cadence | Commitment | Job (Align / Decide / Learn) |
|---|---|---|
|  |  |  |

### Stakeholder

*(The recurring touchpoints with the people in your Audience Maps.)*

| Cadence | Commitment | Job (Align / Decide / Learn) |
|---|---|---|
|  |  |  |

## The Noise list

*(What this rhythm lets me drop. The meetings with no job.)*

-

## How I capture each meeting

Every meeting closes as **O.D.A.**: Outcomes, Decisions, Actions. The weekly roll-up lives in [[_Template - Weekly Update (O.D.A.)|the weekly update]].
