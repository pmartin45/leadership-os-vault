---
type: readme
module: "07 Weekly Updates"
session: "Session 3"
framework: "O.D.A."
tags: [readme, weekly-update, operating-rhythm]
publish: true
---

# 07 Weekly Updates

This folder holds two things: the **operating rhythm** that defines how your week is shaped, and the **weekly update** that becomes the standing artefact of that rhythm.

## What lives here

- **Operating Rhythm**: the three layers (Personal, Team, Stakeholder) and the cadences that hold them. The system that turns Noise into Decide and Learn.
- **Weekly Update (O.D.A.)**: drafted weekly by your Claude Project, refined by you, sent up the chain. Outcomes, Decisions, Actions. Under 150 words, in your voice.

## How it grows

**Pre-work for Session 3** asks you to do a quick self-audit of your last five working days, tagging blocks as Align / Decide / Learn / Noise. You bring the result into Session 3 as input; you do not need to file it as a note.

**Session 3** builds the first artefacts. Duplicate `_Template - Operating Rhythm.md` and design your three layers. Then duplicate `_Template - Weekly Update (O.D.A.).md`, paste the prompt into your Claude Project, and refine the draft until it sounds like you.

**After Session 3**: one update a week. Same shape, every time. The update is how your manager stops getting a 12-bullet status dump and starts getting a signal.

## The rules

- **The audit is a mirror, not a scorecard.** You do not have a time problem. You have an allocation problem. Tag honestly or it tells you nothing.
- **Under 150 words.** The moment it gets longer, it stops getting read.
- **Every Decision and Action has an owner.** "We should" is not an action. "Daniel ships Friday" is.
- **Voice first.** Pull tone from [[Leadership Profile]]. The draft is Claude's; the voice is yours.
