---
type: example
module: "07 Weekly Updates"
session: "Session 3"
framework: "Operating Rhythm"
status: active
tags: [running-case, operating-rhythm]
publish: true
---

# Operating Rhythm: Churn Team

> Worked example. Do not edit. Use it as a reference for designing your own.

> [!quote]
> Leaders design systems. They do not just do more.

## What last week looked like

A self-audit of the previous five days tagged each 30-minute block as Align, Decide, Learn, or Noise. The result: Align 38%, Noise 34%, Decide 16%, Learn 12%. A third of the week was Noise. This rhythm exists to convert that into Decide and Learn.

## The three layers

### Personal

| Cadence | Commitment | Job |
|---|---|---|
| Daily, 90 min | Deep work block, no meetings before 10:00 | Learn |
| Weekly, Fri | Write the O.D.A. update, review open decisions | Decide |

### Team

| Cadence | Commitment | Job |
|---|---|---|
| Weekly | 1:1 with Daniel (validation handoff) | Align |
| Weekly | Team standup, 20 min, blockers only | Align |
| Fortnightly | Model review with the data team | Learn |

### Stakeholder

| Cadence | Commitment | Job |
|---|---|---|
| Monthly | Sarah, retention narrative for the QBR | Align |
| Monthly | Priya, rollout ROI check | Decide |

## The Noise list

- The three standing status meetings I sat silent in. Replaced with the written O.D.A. update.
- The cross-team sync with no agenda. Declined with a C.O.R.E. message.

## How I capture each meeting

Every meeting closes as O.D.A. The weekly roll-up lives in [[EXAMPLE - Weekly Update (Churn Rollout)]].
