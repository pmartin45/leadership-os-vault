---
type: example
module: "07 Weekly Updates"
session: "Session 3"
framework: "O.D.A."
status: active
week: "W## YYYY (example)"
tags: [running-case, weekly-update, oda]
publish: true
---

# Weekly Update: Churn Rollout

> Worked example. Do not edit. Use it as a reference for writing your own. About 95 words.

## Outcomes

- Churn model is live in the campaign workflow. Risk scoring that took two days now runs in minutes. Daniel led week-one validation.

## Decisions

- Full deployment funded (€90K), Priya signed off. Daniel owns validation through Q3.

## Actions

- Daniel ships the validation sign-off Friday.
- I brief Sarah on segment rollout Tuesday.
- We revisit Daniel's delegation level at end of quarter.

---

## Prompt to paste

> Draft my weekly update in O.D.A. format: Outcomes, Decisions, Actions. Use my Leadership Profile for voice. Keep it under 150 words.
