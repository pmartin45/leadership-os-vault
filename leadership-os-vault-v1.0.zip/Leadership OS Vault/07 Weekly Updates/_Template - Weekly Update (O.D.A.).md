---
type: template
module: "07 Weekly Updates"
session: "Session 3"
framework: "O.D.A."
status: template
week: 
audience: 
tags: [template, weekly-update, oda]
publish: true
---

# Weekly Update: [Week of ___]

> Duplicate this file, rename it to the week. Draft in your Claude Project, refine until it sounds like you. Under 150 words.

## Outcomes

*What changed because we worked this week. Not activity, change.*

-

## Decisions

*What we decided, and who owns it.*

-

## Actions

*Who does what, by when.*

-

## Asks and blockers

*What I need from the reader, or what is in the way. If there is nothing, write "none." Do not leave it blank, silence reads as "everything is fine."*

-

---

## Prompt to paste

> Draft my weekly update in O.D.A. format: Outcomes, Decisions, Actions. Use my Leadership Profile for voice. Keep it under 150 words.
