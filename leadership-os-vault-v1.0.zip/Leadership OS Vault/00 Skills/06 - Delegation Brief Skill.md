---
type: skill
module: "00 Skills"
session: "Session 3"
framework: "7 Levels of Delegation"
tags: [skill, delegation, automation]
publish: true
---

# Skill: Delegation Brief

Interview the user about a handoff, name the level of delegation out loud, and produce three artifacts in one pass: a populated Delegation Brief in `06 Delegation Briefs/`, an updated delegation entry on the audience map in `02 Audience Mapping/`, and a delegation entry on the matched project in `11 Projects/`.

The skill stays neutral on which level to pick. It teaches the framework, walks the user through the two dials (readiness, stakes), then lets them choose. Every line in the generated brief traces back to [[_Reference - 7 Levels of Delegation]] rather than being improvised.

## When to Use

- The user is handing a task or a decision area to someone and wants to do it deliberately, not by accident
- They have already named a person to delegate to, or they will once asked
- A current level feels stuck and they want to raise it (or, more rarely, drop it)
- After a step-up review date on an existing brief
- During Session 3, when working through the 7 Levels of Delegation

If the user has not yet built an audience map for the person, the skill still runs, but flags up front that a map first would sharpen this.

## How It Works

1. Scan the vault for context (silent)
2. Gate check: is this decision actually yours to keep?
3. Capture the person, the project, and the task
4. Walk the two dials (readiness, stakes) as a self-check, no recommendation
5. Explain the seven levels, let the user pick
6. Set guardrails, the step-up target, and check authority matches responsibility
7. Generate the brief, the audience map update, and the project updates
8. Review, confirm, write

If a brief already exists for this person on this work, treat this as a level move (up or down) rather than a fresh handoff.

## Phase 0: Scan the Vault

Before asking anything:

```bash
# The 7 Levels reference, used as source for every generated section
cat "06 Delegation Briefs/_Reference - 7 Levels of Delegation.md" 2>/dev/null

# The user's profile, so the skill knows who is delegating
cat "01 Leadership Profile/Leadership Profile.md" 2>/dev/null

# Existing audience maps
ls "02 Audience Mapping"/*.md 2>/dev/null | grep -v "_Template\|EXAMPLE\|README"

# Existing delegation briefs, to detect prior handoffs to the same person on similar work
ls "06 Delegation Briefs"/*.md 2>/dev/null | grep -v "_Template\|_Reference\|EXAMPLE\|README"

# Project folders
ls "11 Projects" 2>/dev/null | grep -v "PROJECT TEMPLATE"
```

Record:
- The reference structure for every level (definition, example phrasing, what it entails, pitfalls, signals the level is wrong). The skill pulls from this verbatim; it does not paraphrase.
- The user's name, role, top 3 stakeholders
- Whether an audience map exists for the person about to be named
- Whether any prior brief exists for the same person on similar work, and at what level. If yes, this is a level move, not a first handoff.
- Active projects, so Phase 2 can match

Do not narrate the scan.

## Phase 0.5: The "is this even mine to keep?" gate

Before going further, ask once, plainly:

> *"Quick gate before we go further: does this decision actually need to sit with you at all? Or are we about to spend energy picking a level on something that should be off your plate entirely?"*

If they hesitate or say no, do not push to a brief. Suggest they hand it off without ceremony and exit the skill. If they say yes, this is genuinely theirs to delegate, continue.

This gate exists because the reference names it as decision check #1: *"Is this even mine to keep?"* Skipping it means the skill helps the user delegate things they should have offloaded entirely.

## Phase 1: Who

Ask:

> *"Who are you delegating to?"*

Match the name against `02 Audience Mapping/`. Three branches:

**Map exists.** Read it silently. Pull:
- Personality and working style (informs the "How to say it" tone)
- How they consume information (informs channel and format for the conversation)
- What makes them shut down (feeds directly into "What to avoid")
- Notes for Claude (voice patterns)

Say back briefly: *"Got it, working from your map of [Name]. They're a [direct report / peer / boss / cross-functional], they prefer [channel], and the thing that shuts them down is [pattern]. I'll factor that in."*

**No map exists.** Capture name and role lightly (one line each). Flag: *"You don't have an audience map for [Name] yet. We can still write the brief, but running the Audience Map Builder first would sharpen the 'how to say it' section. Continue, or pause and map them first?"* If continue, the skill proceeds; the "How to say it" section will be thinner.

**Prior brief exists for this person.** Note it back: *"You have a brief from [date] for [Name] on [task], at Level [N]. Is this a level move on the same work, or a separate handoff?"* If a level move, jump to Phase 4 with that history loaded.

## Phase 2: Which project

Ask:

> *"Which project does this handoff live inside?"*

Match against folders in `11 Projects/`. Three branches:

**Project matches.** Read the project's `CLAUDE.md` for context. Note any existing `## Delegations` section.

**No matching project.** Ask: *"Is this a one-off handoff outside any project, or a project that doesn't exist in the vault yet?"* If one-off, capture the context inline and skip the project-file write at the end. If it should exist but doesn't, suggest running the New Project skill first, then return here.

## Phase 3: What, specifically

Three prompts, in this order. Push for concrete answers. If the answer is muddy, probe once.

> *"What's the task in one line? Not 'own analytics,' something concrete like 'own Q4 churn-model validation.'"*

> *"What does done look like? The finish line, concrete enough that they'll know when they've crossed it."*

> *"Is this a one-off task, or a decision area you'll be moving up the dial over time?"*

The third prompt comes from the reference's framing: *"You delegate decisions, not people."* It shapes the audience map update. A decision area gets named explicitly so the level can move within that area over time; a one-off task gets logged as a single handoff.

If the user can't say done in a sentence, do not let them move past this. Muddy "done" is the single biggest source of muddy delegation downstream. Probe: *"If you saw them three weeks from now, what would they have produced that would let you say 'they crossed it'?"*

## Phase 3.5: The two-dial self-check

Walk the two dials from the reference. This is a structured think-aloud, not a recommendation. Each dial gets a forced score on a 1-to-5 scale with explicit anchors, plus one line of evidence. The score makes the user take a position; the evidence makes sure the position is grounded in something specific, not a feeling.

Print the anchors for each dial. Ask for the score, then the evidence. Capture both verbatim for the brief's Notes section.

### Dial 1: Readiness

> *"First dial: readiness. How proven are they on this specific kind of work? Track record on this work, not their seniority in general. Pick a number, 1 to 5."*

```
1  Brand new. No track record on this kind of work. They have never
   made decisions in this area.
2  Some exposure, always under direction. They have done pieces of it
   with you driving. Their judgment in this area is unproven.
3  A handful of calls, mixed or limited sample. You can point to some
   decisions but not yet a pattern. The hard cases are still unknown.
4  Track record on routine cases. Multiple calls, most landed well. You
   would trust them on the standard cases, but not the edge cases yet.
5  Proven across the full range. Consistent good calls including the
   hard ones. You cannot remember the last time their judgment
   surprised you for the worse.
```

After they pick:

> *"What's the evidence? One specific thing that puts them at a [N] and not a [N-1] or [N+1]. A decision they made, a pattern you have seen, something concrete."*

If they cannot name evidence, do not let them stay at the higher score. Drop them one notch and capture that: *"You picked a 4 but could not name evidence above a 3. Let's hold it at 3 for now. If evidence shows up before the review date, raise it."*

### Dial 2: Stakes

> *"Second dial: stakes. The cost of a wrong call here, and how reversible it is. Pick a number, 1 to 5."*

```
1  Low cost, easily reversible. A wrong call costs little and can be
   undone in a day. The team learns and moves on.
2  Mild cost, mostly reversible. A wrong call is annoying but fixable
   in a week. The blast radius stays inside the team.
3  Real cost, recoverable. A wrong call is visible inside the function,
   takes effort to unwind, but no one outside has to know.
4  Significant cost, hard to reverse. A wrong call touches stakeholders
   outside the team, costs weeks to unwind, and you will have to
   explain it.
5  High cost, irreversible. A wrong call is visible to the executive
   line, customers, or regulators. It cannot be undone, and the cost
   compounds.
```

After they pick:

> *"What's the evidence? One line on what makes it a [N]. The specific cost or the specific thing that makes it hard to undo."*

### Capture and neutrality

Capture both scores and both evidence lines verbatim. They land in the brief's Notes section as:

```
- Readiness: <N>/5. <evidence line>
- Stakes: <N>/5. <evidence line>
```

The skill does not translate these scores into a level recommendation. The dials prime the user's own thinking; the level pick in Phase 4 stays theirs.

If they ask *"so which level should I pick based on these scores?"*, answer honestly: *"I'm holding neutral on that on purpose. The framework says readiness and stakes are the two main dials, so you have now weighed both, with evidence. Pick from there."*

## Phase 4: The level

Explain the seven levels in their language, lean. Use the reference's "move in one line" for each, paired with the example phrasing so they can hear what each level actually sounds like.

```
1. Tell.            "Here's what to do."                   You decide, they execute.
2. Sell.            "Here's what to do, and why."          You decide, you explain why.
3. Consult.         "Give me your input, then I decide."   You ask, then you decide.
4. Agree.           "We decide together."                  You both decide, as equals.
5. Advise.          "Here's my advice, but you call it."   They decide, you advise.
6. Inquire.         "You decide, then tell me."            They act, they tell you after.
7. Delegate Fully.  "It's yours. I don't need to be in it." They own it completely.
```

Then **AskUserQuestion**:

> **At what level are you delegating this?**
> - Level 1, Tell
> - Level 2, Sell
> - Level 3, Consult
> - Level 4, Agree
> - Level 5, Advise
> - Level 6, Inquire
> - Level 7, Delegate Fully

### Optional: name a growth target

After they pick the current level, ask once:

> *"Do you want to name where this is going next, the level you'd like to grow them to on this work and roughly when? Optional. If not, we'll just hold the current level and move on."*

Use **AskUserQuestion** with two options: *Yes, name a target now* and *No, just hold the current level*.

**If yes**, ask:

> *"What level are you aiming for next on this work, and by when?"*

Capture both. They flow into the conditional fields on every downstream artifact (frontmatter `level_target`, the "Aiming for" line in the brief body, the audience map entry, the project CLAUDE.md table, and the project Delegations.md note). The downstream templates below mark each of these as `<if target named, else omit>`.

**If no**, skip the prompt. None of the conditional aim-for fields are written. The brief stays focused on the current rung. The user can run this skill again later on the same person and task to add a target then.

## Phase 5: Guardrails, step-up, and the authority check

Three prompts.

> *"What's safe for them to decide without you? The explicit guardrails, the range they can move in without checking. Be specific, like 'adjust thresholds within plus or minus 2 points without me, anything wider flag it first.'"*

> *"What do you need back, and when? The one thing you want, and the moment you want it. Not a status report cadence, the one signal."*

> *"Step-up review date: when are you revisiting whether to raise the level?"*

Then the two authority/information checks from the reference's pitfalls, fast:

> *"Two quick checks before we generate. One: do they have the context, access, and data they need to act at this level? Two: are you giving them the authority that matches the responsibility, or just the responsibility?"*

If either answer is no, do not block, but capture what's missing in the brief's Notes section so they see it.

## Phase 6: Generate

Three artifacts. Generate, show, write only after confirmation on each.

### Artifact 1: The Delegation Brief

**Filename:** `06 Delegation Briefs/<YYYY-MM-DD> - <First Name> - <Task>.md`. Date first, then name, then task, so briefs sort chronologically in the folder and you can see at a glance when each handoff happened. Example: `2026-06-03 - Daniel - Churn Validation.md`. If a file with that exact name already exists (same person, same task, same day), append a short qualifier (e.g. `2026-06-03 - Daniel - Churn Validation Q2.md`) rather than overwrite.

Use `date +%Y-%m-%d` to get today's date; do not hardcode or guess.

**Frontmatter** (pre-filled):

```yaml
---
type: note
module: "06 Delegation Briefs"
session: "Session 3"
framework: "7 Levels of Delegation"
status: active
owner: <First Name>
level_now: <1-7>
level_target: <1-7, if target named in Phase 4, else omit this line>
decision_area: <if named in Phase 3, else omit>
project: <project folder name if matched, else omit>
review_date: <step-up date>
tags: [delegation, <name-lowercased>]
publish: true
---
```

`publish: false`. Real handoffs are private. Templates and EXAMPLEs publish; filled-in briefs do not.

**Body** (match the existing template's structure, then add the four new sections at the end):

```markdown
# Delegation Brief: <Task>

## The handoff

- **Task:** <one line from Phase 3>
- **Owner:** <Name and role>
- **Decision area:** <if named, else omit this bullet>
- **Project:** <if matched, else omit>

## The level

- **Level now:** <N>, <Level name>. *"<the move in one line from the reference>"* <one user-voice sentence on what that sounds like here>
- **Aiming for:** <M>, <Level name>. *"<the move in one line>"* Target: <date>. <one user-voice sentence on the destination> *(omit this bullet entirely if no target was named in Phase 4)*

See [[_Reference - 7 Levels of Delegation]].

## The guardrails

- **What "done" looks like:** <from Phase 3>
- **Safe to decide without me:** <from Phase 5>
- **What I need back and when:** <from Phase 5>

## The step-up

- **Step-up review date:** <from Phase 5>

## How to say it

<Three to five bullets. Open with the example phrasing for the chosen level from the reference, adapted to this task and this person's voice (pulled from their audience map if it exists). Name the level out loud in the conversation. Phrase the guardrails in the user's words. Cover both what they're committing to and what the team member is committing to ("what it entails for each side" from the reference).>

## What to avoid

<Three to five bullets, pulled from the chosen level's "Pitfalls" section in the reference plus any relevant cross-cutting pitfalls from Section 8. Adapted to this person, especially anything from the audience map's "what shuts them down" that overlaps. Examples for Level 5: "Advice that's really a command in disguise." "Overruling after the fact, even quietly." "Flooding them with advice until the decision is effectively yours again.">

## Mindset to bring

<Two to four bullets, pulled from the chosen level's "What it entails for the manager" plus the cross-cutting principle that fits (e.g. "delegation is not abdication," "responsibility without authority is a trap"). The line that names what the user will have to *resist*, not just what to do. Example for Level 5: "Tolerate decisions you would have made differently. The whole point is their judgment is the answer.">

## Signals to watch for

<Two to four bullets, pulled directly from the chosen level's "Signals the level is wrong" in the reference. These are the cues that say it's time to move up (or, rarely, down) at the next review. Example for Level 5: "They rarely need the advice and consistently decide well without it. Move to Inquire." "They're clearly struggling and stakes are high. Step back to Consult or Agree.">

## Notes

<Anything from Phase 3.5 (readiness, stakes) that didn't fit above. Anything they flagged on the authority/information check that's missing. What they're nervous about handing over. If this is a move down, the reason and the path back up.>
```

**Generation rules:**

- **Pull from the reference, do not paraphrase.** The "How to say it / What to avoid / Mindset / Signals" sections are scaffolded from the reference's per-level structure. Adapt to this task and this person, but the substance traces back to the source.
- **Use the user's words.** If the user said "Daniel quietly worries AI makes his judgment redundant," write that. Don't generalize.
- **Don't fabricate.** Thin answer to a Phase 5 prompt → thin section. If they couldn't name a guardrail, write "*To define before the conversation*" rather than invent one.
- **Lead each section with the punch line, not preamble.** Look at [[EXAMPLE - Daniel - Churn Validation]] for tone.
- **No em dashes or en dashes anywhere.** Commas, colons, periods, parens. The `→` glyph is fine.

### Artifact 2: Audience Map update

If an audience map exists for the person, append (do not overwrite) a delegation entry. If the map has no `## Delegations` section, add one at the end (after `## Notes for Claude`).

```markdown
## Delegations

- **<Decision area or task>** ([[<brief filename>]]), Level <N> (<Level name>)<if target named: , aiming for Level <M> by <target date>>. Review: <review date>. Logged <today>.
```

If multiple delegations accrue over time, they list under this section in order of most recent. The skill never deletes prior entries.

If no audience map exists, skip this write and tell the user: *"No audience map for [Name] yet, so I didn't log the level there. When you build one, the delegation will live in a `## Delegations` section."*

### Artifact 3: Project updates (two writes)

Only if a project was matched in Phase 2.

**Write A: One-liner in the project's `CLAUDE.md`.**

Append to (or create) a `## Delegations` section in the project's root `CLAUDE.md`. Use a table so Claude can scan it quickly when working in the project:

```markdown
## Delegations

| Date | Owner | Decision area / task | Level | Review | Brief |
|------|-------|----------------------|-------|--------|-------|
| <today> | <Name> | <decision area or task> | <N><if target named: → <M>> | <review date> | [[<brief filename>]] |
```

If the table already exists, prepend the new row above existing rows.

**Write B: Full note in the project folder.**

Drop a note at `<project folder>/Delegations.md` (create if it doesn't exist). One section per delegation, prepended above prior entries:

```markdown
## <today>: <Decision area or task>, <Name>

- **Level:** <N> (<Level name>)<if target named: , aiming for <M> (<Level name>) by <target date>>
- **Done looks like:** <from Phase 3>
- **Review:** <review date>
- **Brief:** [[<brief filename>]]
- **Context:** <one line on why this handoff matters for the project right now>
```

If the project folder uses a different convention (e.g., a `Skills` or `Process` subfolder with its own logging pattern), surface that to the user before writing and ask where it should land.

## Phase 7: Review and confirm

Show all three artifacts in order, briefs first, then map update, then project updates. Ask:

> *"Three writes incoming: the brief, the audience map update, and the project updates. Anything to change, sharpen, or pull before I save?"*

Edit targeted sections based on their feedback. Don't regenerate the whole brief. Loop until they confirm.

Write the files only after explicit confirmation. Confirm each write back in chat using wikilink format so the user can click through:

- Brief saved at `[[06 Delegation Briefs/<YYYY-MM-DD> - <Name> - <Task>]]`
- Map updated at `[[02 Audience Mapping/<Name> (<Role>)]]` (if applicable)
- Project updates: `[[11 Projects/<Project>/CLAUDE]]` and `[[11 Projects/<Project>/Delegations]]` (if applicable)

## Phase 8: Wrap

After saving, tell the user:

1. **The level is named out loud now.** That was the whole point. From here, the brief is the contract; the map and project files are the trace.
2. **The review date is on the brief.** When that date arrives, run this skill again on the same person and task; the skill will detect the prior brief and treat the conversation as a check on the current level rather than a fresh handoff.
3. **The "Signals to watch for" section is your cue.** If those signals show up before the review date, act on them deliberately rather than waiting. `<if target named: That might mean moving them toward the target sooner, or pausing the path and rethinking.>`
4. **The brief is `publish: false`.** Real handoffs stay private even if Obsidian Publish is on later.
5. **Sparring partner mode is available.** If they want to pressure-test the choice (level fit, guardrail clarity, "done" concreteness), they can ask now or later; the skill stays neutral by default but will push on request.

Do not offer to scaffold notes in other folders. Keep this skill focused on the handoff.

## Sparring partner mode (on request)

If the user asks for sparring at any phase, switch tone briefly. Pull from the reference's principles to pressure-test:

- **On level fit:** *"You picked Level [N]. The reference's most common failure is delegating one level too low to feel safe. Re-check: is this level reflecting their readiness, or your nerves?"*
- **On guardrails:** *"Are these guardrails specific enough that they'll know when they've crossed them, or vague enough that they'll come back to ask?"*
- **On "done":** *"If they showed you the finished work, what would tell you they crossed the finish line? If you can't name it, neither can they."*
- **On responsibility-without-authority:** *"You've given them the outcome. Have you given them the authority that matches it, or just the responsibility?"*

Push once per dimension, accept their answer, return to neutral. Sparring is a service, not an argument.
