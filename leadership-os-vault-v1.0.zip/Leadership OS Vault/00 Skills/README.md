---
type: readme
module: "00 Skills"
session: "Ongoing"
framework: ""
tags: [readme, skills, automation, meta]
publish: true
---

# 00 Skills

> **First time here?** Go back to the [[README.md|vault README]] first. The very first skill you must run is **Brain Setup** ([[00 - Brain Setup Skill]]). It writes your `CLAUDE.md` and is a prerequisite for every other skill in this folder.

This folder holds all the Claude Skills and automation patterns that enable you to work with your Leadership OS vault more efficiently.

## What lives here

- **Interactive framework guides**: Structured prompts that walk you through creating or updating artifacts
- **Automation patterns**: Reusable Claude instructions for common tasks
- **Decision trees**: Question hierarchies for different workflows

## How it works

When you want to create or edit something (e.g., map a new stakeholder, draft a message to an audience), you invoke the relevant skill. The skill asks you targeted questions, uses your existing vault context, and either scaffolds new notes or updates existing ones.

The skill becomes an extension of the framework itself, it knows the template structure, the README guidance, and the conventions. You answer the questions; the skill builds the artifact.

## The skills

| Skill | Purpose | Use when |
|-------|---------|----------|
| **[[00 - Brain Setup Skill\|Brain Setup]]** (run first) | Scans the vault, interviews you, writes your personalized `CLAUDE.md` so Claude can think with you about *your* leadership context | The very first thing you do after opening the vault. Required before any other skill works well. |
| **[[01 - Leadership Profile Skill\|Leadership Profile]]** (run after Brain Setup) | Walks you through filling in `01 Leadership Profile/Leadership Profile.md` section by section. Writes each section to the file as you answer, so progress is preserved. | You're doing the Pre-Work and need to fill in your Leadership Profile, or your role/team/stakeholders have changed and the profile is stale |
| **[[02 - Audience Map Builder Skill\|Audience Map Builder]]** | Interviews you about a stakeholder (lean 3-round capture or deep 5-round map) and produces a populated Audience Map in `02 Audience Mapping/`. Branches questions by relationship type (report / boss / peer / cross-functional). | You have a new stakeholder to map, or an existing map has gone stale |
| **[[03 - Influence Plan Skill\|Influence Plan Builder]]** | Walks you through influencing a specific person on a specific ask: goal, person, project, then translates the ask into *their* world (what they own, their pain, the bridge), names the friction, picks one strategy, defines the smallest first yes, and drafts the actual move. Saves an Influence Plan in `03 Stakeholder Drafts/` and cross-links it into the audience map and (if any) the project. | You need to move a specific person on a specific decision, resource, or permission, and want a plan that lands a small visible yes this week, not a wish |
| **[[04 - Storytelling Skill\|Storytelling (T→I→O)]]** | Takes a rough idea or update, locks the audience and the change you want to land, then builds a Tension → Insight → Outcome note plus a ready-to-send draft in the format the audience consumes. | You have something to say to a specific stakeholder and you want it to land, or a message you already wrote is not landing and needs its spine found |
| **[[05 - C.O.R.E. Message Skill\|C.O.R.E. Message]]** | Branches on project or person, pulls the Leadership Profile and the relevant Audience Map, names the actual fear, and drafts a C.O.R.E. (Context / Outcome / Relevance / Expectations) message with an empathy opener and a two-touch reinforcement plan in `05 Change Communication/`. | You are leading a change and one specific person is going Withdrawn, Skeptic, Observer, or Advocate, and you need a message that converts silence or pushback into a Small Yes |
| **[[06 - Delegation Brief Skill\|Delegation Brief]]** | Walks you through a handoff (person → project → task → readiness/stakes self-check → level → guardrails), then writes three artifacts in one pass: a Delegation Brief in `06 Delegation Briefs/` (with How to say it / What to avoid / Mindset / Signals sections), a delegation entry on the audience map, and a delegation entry on the matched project. Neutral on level choice. Every line in the brief traces back to [[_Reference - 7 Levels of Delegation]]. | You are handing a task or a decision area to someone and want to name the level out loud, or a step-up review date has arrived and you are moving someone up (or, rarely, down) the dial |
| **[[08 - Backlog Triage Skill\|Backlog Triage]]** | Captures this week's list (from your input plus due-soon signals it spots in the vault), then triages each item through one of four framework lenses (Priority Grid, RICE, Eisenhower, Cost of Delay), captures reasoning per item, and writes a structured `W## YYYY - Backlog Triage.md` page in `08 Prioritization/`. Targeted, not exploratory. | Weekly planning kickoff, mid-week reset when the list feels overloaded, or before a major push when you need to confirm what actually matters |
| **[[11 - New Project Skill\|New Project]]** | Interviews you in 6 questions, then scaffolds a new project folder under `11 Projects/` with its own `CLAUDE.md` and `COMMANDS.md`, and registers it in the root `CLAUDE.md` | You're starting a new project (client engagement, initiative, body of work) and want Claude to hold context for it across sessions |
| *(more skills coming as you identify workflow friction)* | | |

## Philosophy

Skills live here so they are versioned with the vault, not buried in a Claude project prompt. If the template changes, the skill documentation changes alongside it. The vault owns its own tooling.
