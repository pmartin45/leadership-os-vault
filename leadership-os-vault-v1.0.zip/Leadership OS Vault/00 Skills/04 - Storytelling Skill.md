---
type: skill
module: "00 Skills"
session: "Session 1"
framework: "T→I→O"
tags: [skill, storytelling, automation]
publish: true
---

# Skill: Storytelling (Tension → Insight → Outcome)

Take a rough idea, observation, or update from the user and turn it into a Tension → Insight → Outcome note in `04 Storytelling/`, plus a ready-to-send draft in the format the audience actually consumes (email, one-pager, three slides, verbal).

The user comes in with raw material: "I want to tell this story about…", "I need to message Sarah about…", "Something happened in the QBR and I want to write it up." Your job is to ask the few questions that find the spine, then build the artifact.

## When to Use

- User says "let's draft a story", "help me write this up", "I want to message X about Y", "turn this into something I can send"
- User has a rough thought, observation, or update that needs to land with a specific audience
- A message they already wrote is not landing and they want to find the spine
- During Session 1, when working through the T→I→O framework on a real case

If the user has not yet picked an audience or named what they want to land, do not start drafting. Ask first. A story without an audience and a desired change is not a story, it is a recap.

## How It Works

1. Scan the vault for context (silent)
2. Capture the raw material in the user's own words
3. Lock the audience first (this is the branching point for everything else)
4. Round through Tension, Insight, Outcome with one focused question each, plus the "why it matters" check
5. Generate the T→I→O note and the actual draft in the right format
6. Review, edit, save

If a T→I→O note already exists for this audience and topic, ask whether to refresh in place or start fresh.

## Phase 1: Scan the Vault

Before asking anything:

```bash
# Pull the user's profile so you know who is writing and how they sound
cat "01 Leadership Profile/Leadership Profile.md" 2>/dev/null

# See which audience maps exist (drop README/EXAMPLE/Template noise)
ls "02 Audience Mapping"/*.md 2>/dev/null | grep -v "_Template\|EXAMPLE\|README\|^00 "

# See which T→I→O notes already exist
ls "04 Storytelling"/*.md 2>/dev/null | grep -v "_Template\|EXAMPLE\|README\|^00 "

# Reference: the template and the worked example
cat "04 Storytelling/_Template - Tension-Insight-Outcome.md"
cat "04 Storytelling/EXAMPLE - T-I-O (Churn Retention).md"
```

Record:
- The user's voice notes from the Leadership Profile (register, words they use, words they refuse)
- The list of real audience maps available
- Any existing T→I→O notes that might be on the same topic
- The format preference and shutdown triggers of any audience the user is likely to pick (read the map before drafting)

Do not narrate the scan. Just use what you learn.

## Phase 2: Capture the Raw Material

Open with one question, plainly:

> "Tell me what you want to say. In whatever form, doesn't matter. The observation, the frustration, the thing that happened, the point you want to land. Fragments are fine, I will tidy it."

Let them dump. Do not interrupt with structure yet. Capture verbatim. This raw material is what you will mine for Tension and Insight in later rounds, so do not paraphrase it away early.

If they give you one line, probe once:

> "Say more. What is underneath that? What is the thing they are not seeing, or the thing that is stuck?"

Then move on. Don't interrogate.

## Phase 3: Lock the Audience

This is the first hard question and it shapes everything that follows. Use **AskUserQuestion**.

Build the options dynamically from the audience maps you found in Phase 1. Show up to 4 of the most likely candidates (top 3 stakeholders from the Leadership Profile, plus any map referenced in the raw material).

> **Who is this story for?**
> - **`<Name 1>` (`<Role>`)** [from existing map]
> - **`<Name 2>` (`<Role>`)** [from existing map]
> - **`<Name 3>` (`<Role>`)** [from existing map]
> - **Someone else / no map yet**

**If they pick an existing map:** Read it fully. Pin the four things you will need to honor:
- Format preference (email, one-pager, slides, verbal)
- Length tolerance
- What makes them shut down (the trigger phrases, the topics, the framings)
- Voice notes (openings to use, openings to avoid, language to match)

Say back, in one line: "Okay, drafting for `<Name>`. They want `<format>`, max `<length>`, lead with the `<so-what / build-up>`. I will avoid `<trigger>`."

**If they pick "someone else / no map yet":** Pause. Two options:

> "Two paths. Either we run the Audience Map Builder first (5 minutes, gives me what I need to draft in their voice), or you give me the basics inline: name, role, format preference, what makes them shut down. Which?"

If inline, capture the four fields and keep going. If they want to map first, hand off to the **Audience Map Builder** skill and resume here when the map is saved.

## Phase 4: Lock the Change You Need to Land

Before any of the T, I, O rounds. Ask:

> "What is different after they read this? One sentence. A decision they make, a meeting they take, a number they fund, a position they shift. If you cannot picture what changes Monday morning, we are not ready to draft yet."

If the answer is vague ("I want her to understand the situation"), push once:

> "Understand it and do what? What is the move you want from her?"

Capture this as the **change to land**. Everything downstream serves this one sentence. If you cannot get a sharp answer after one probe, name it: "Okay, we do not have a sharp outcome yet. Want to think out loud about it, or come back when it is clearer?" Do not draft a T→I→O against a fuzzy change. Soft change, soft message.

## Phase 5: Find the Spine (T → I → O)

Three short rounds. After each, **summarize back in one line** so the user can correct before you move on. Probe once on thin answers, then move on.

---

### Round T: Tension

> "What is the friction? What is not working, what is unresolved, what is at stake right now for them?"

The tension is theirs, not yours. The CMO does not feel "our model is underused." She feels "I do not have a clean answer when the board asks where the leaky bucket is." Translate the user's framing into the audience's felt friction.

If they give you a soft tension ("the team could be doing better"), name it:

> "That is soft. Soft tension makes a soft message. What is the actual stake? What breaks if this does not move?"

Summarize back: "Tension: `<one sentence in audience-felt language>`."


### Round I: Insight

> "What is the non-obvious thing you are seeing that they are not? Not a recap of the tension, the reframe. The thing that, if they got it, would change how they think about the problem."

This is the highest-leverage round. The insight is what makes it a story instead of a status update. If the user just restates the tension in different words, push:

> "That is the tension again. The insight is what is happening underneath it. What do you see that they do not? Why is the obvious read of this situation wrong?"

If they cannot find one, ask:
- "What surprised you when you looked at this?"
- "What is the thing you would say in a one-on-one but not in a meeting?"
- "If they kept reading the situation the way they currently do, what would they get wrong?"

Summarize back: "Insight: `<the reframe, one sentence>`."

---

### Round O: Outcome

> "What is the specific, concrete change that follows from the insight? A decision, a number, a risk owned, a next step with a name on it."

Force concrete. If the answer is "we should invest more in retention," push:

> "Concrete. How much, from where, owned by whom, decided by when? If you cannot picture Monday morning, the outcome is not sharp enough."

The outcome should be the move that is now obvious *because* of the insight. If the outcome could have been written without the insight, the insight is not doing work.

Summarize back: "Outcome: `<decision / number / owner / next step>`."

---

### Round W: Why it matters

One question, fast:

> "One line. Why is this story worth telling at all? Business reason or human reason, either fine."

If they cannot answer, name it: "If we cannot answer this, it is not a story, it is a recap. Want to keep going anyway, or rethink?"

Capture as a single line.

## Phase 6: Generate the T→I→O Note

**Filename:** `T-I-O (<Topic>).md` in `04 Storytelling/`. Match the EXAMPLE pattern. So `T-I-O (Churn Retention).md`, not `EXAMPLE - T-I-O.md`, not `storytelling-churn.md`. If a file with that name exists, append a short qualifier (e.g. `T-I-O (Churn Retention Q3).md`). Keep the topic short, 2 to 4 words.

**Frontmatter** (pre-filled):

```yaml
---
type: note
module: "04 Storytelling"
session: "Session 1"
framework: "T→I→O"
status: active
theme: <one of: Leadership / Impact / AI / Change / Collaboration / or the user's own>
audience: <First Name>
tags: [storytelling, <name-lowercased>, <theme-lowercased>]
publish: true
---
```

`publish: false`. Real stakeholder-bound stories are private. The template and EXAMPLE publish; filled-in notes do not.

**Body** (match the template structure exactly, in this order):

```markdown
# T → I → O: <Topic>

## Context

- **Audience:** [[<Name> (<Role>)]]
- **The change I need to land:** <one sentence from Phase 4>
- **The format this becomes:** <email / one-pager / three slides / verbal>

## Tension

<one tight paragraph or 1-2 bullets, in audience-felt language>

## Insight

<the reframe, one tight paragraph. Lead with the punch line.>

## Outcome

<the concrete move. Decision, number, owner, next step.>

## Why it matters

<one line>

## The draft

<the actual message, written in the user's voice, in the format the audience consumes. The T→I→O spine should be visible in the structure even if the words "tension" and "insight" never appear. See the rules below.>

---

## Working notes

- <pull 1-3 short notes from the audience map: triggers to avoid, phrases to match, the format constraint that shaped this draft>
```

**Drafting rules for the message itself:**

- **Use the user's voice.** Pull from the Leadership Profile and the audience map's "Notes for Claude" section. If the profile says "I write in short paragraphs, never open with 'I wanted to share'," respect that.
- **Match the audience's format.** If their map says "one page, max five slides, hates 40-slide decks," do not produce a memo. Match the artifact they actually read.
- **Lead with the so-what** if the map says so. Most senior audiences want the headline first. Confirm against the map.
- **Strip everything the map says shuts them down.** If Sarah's map says "leading with methodology makes her tune out," do not open with the model. Open with the timing.
- **Spine visible, words invisible.** The reader should feel the T→I→O structure without the labels. Do not write "Tension:" "Insight:" "Outcome:" in the draft itself. That is for the spine section above.
- **No em dashes or en dashes anywhere.** Vault convention. Commas, colons, periods, parens. The `→` glyph is fine.
- **Don't fabricate facts.** If the user gave you a vague number, leave a placeholder in square brackets (e.g. `[X accounts]`) rather than inventing one. Better an honest gap than a confident lie.

## Phase 7: Review & Confirm

Show the full generated note. Ask:

> "Here is the spine and the draft. Two things to check: does the spine feel right (Tension, Insight, Outcome), and does the draft sound like you? Anything to sharpen before I save?"

Make targeted edits to what they flag. Don't regenerate the whole document. If they want a bigger rework, ask which section, and rework only that one. Loop until they say it is good.

Write the file only after explicit confirmation. Save to `04 Storytelling/T-I-O (<Topic>).md`.

## Phase 8: Wrap

After saving, tell the user:

1. **Note saved** at `[[04 Storytelling/T-I-O (<Topic>)]]`
2. **It is set to `publish: false`** so the real story stays private even if Obsidian Publish is on.
3. **The draft is in the `## The draft` section.** Copy from there, send in the format the audience expects.
4. **If the audience does not respond the way the outcome predicts**, the insight was wrong, not the words. Come back and rework the spine, not the prose.
5. **Theme is tagged** in the frontmatter (`theme:`). Over time `04 Storytelling/` becomes a searchable library you can pull from for talks, updates, retros, and interviews.

Do not offer to scaffold notes in other folders. Keep this skill focused on the story.

## Critical Rules

- **Audience first, always.** No drafting until the audience is locked and you have read their map.
- **Change to land second.** No T→I→O rounds until you have a one-sentence answer to "what is different after they read this?"
- **One probe per thin answer, then move on.** Don't interrogate. The user told you to guide them.
- **Use their words.** Mirror the user's phrasing in the spine. Mirror the audience's expectations in the draft.
- **Never fabricate.** Thin material, thin draft, with placeholders for what is missing. Never invent a number, a name, or a quote.
- **Don't touch the EXAMPLE or Template files.** Read them for calibration; never edit them.
- **Spine before prose.** If the user asks you to "just write it" before the T, I, and O are locked, push back once: "Let me lock the spine first, the draft writes itself after that." Then do it.
