---
type: skill
module: "00 Skills"
session: "Session 4"
framework: "Backlog Triage"
tags: [skill, prioritization, automation]
publish: true
---

# Skill: Backlog Triage

Walk the user through a weekly backlog triage and write the result to `08 Prioritization/W## YYYY - Backlog Triage.md`. Pull items from a pasted task list or from `11 Projects/`, ask a short fixed set of framework-aligned questions per item, then render a 2×2 grid (or ranked list) at the bottom of the page.

This is a targeted triage, not a sparring session. The questions are diagnostic, just enough to land each item in the right quadrant and move on.

## When to Use

- Weekly planning kickoff
- Mid-week reset when the list feels overloaded
- Before a major push, to confirm what actually matters

## How It Works

1. Scan vault context (silent), projects, decision log, last week's triage, due-soon signals
2. Resolve the week page (new file → capture flow; existing file → append flow)
3. Capture this week's priorities from the user, tie each to a project, then surface any due-soon items I noticed in the vault and ask one-shot whether to add them
4. Write the captured list to the page, this becomes the source of truth for the rest of the session
5. Ask which framework to triage by
6. Run the question set per item, including reasoning capture
7. Ask the session-level "why this shape" rationale
8. Append the session notes and grid to the page

## Phase 1: Scan the Vault

Before asking anything:

- Read `08 Prioritization/_Template - Backlog Triage.md` to load the quadrant language verbatim (Do / Sequence / Delegate / Decline phrasing). Reuse it in the page output.
- `Glob 11 Projects/**/*.md` to enumerate project files. Keep the list, it powers project-tie matching in Phase 3b.
- Filter the project list to project root files (e.g. `CLAUDE.md`, `README.md`, or top-level project notes). If unsure, list every `.md` and let the user multi-select.

**Also scan for due-soon signals** to power the "anything I noticed" pass in Phase 3c. Look across:

- `11 Projects/**/*.md`: `Grep` for `TODO`, `- [ ]` checkbox items, "due", "by `<date>`", and explicit dates in the next 7 to 14 days.
- `09 Decision Log/**/*.md`: open decisions or commitments with a date attached.
- The **previous week's** backlog triage page in `08 Prioritization/`: anything that landed in **Sequence later** that might now be due, or items that didn't get resolved.
- Any meeting notes inside project folders (search for filenames containing `meeting`, `notes`, `1-1`, dated patterns like `YYYY-MM-DD`).

Hold these as a **candidate suggestion list**: `{item, source-file, why-it-surfaced}`. Cap at 5 to 7 items. If you find more, keep only the highest-signal ones (explicit dates closest to this week, items from the user's top projects).

Do not narrate the scan. Just use what you learn.

## Phase 2: Resolve the Week Page

Compute the ISO week:

```bash
date +'%G W%V'
# → e.g., 2026 W23
```

Target path: `08 Prioritization/W23 2026 - Backlog Triage.md`. Capitalized words, no leading underscore (underscore is reserved for templates).

- **New file** → run Phase 3 (Capture) from scratch.
- **Existing file** → read it, show the user the captured list so far, and ask whether they want to (a) add more items, then triage, or (b) skip straight to a fresh triage session over the existing list.

Do not overwrite an existing week page. Always append.

## Phase 3: Capture This Week's Priorities

This is the foundation. The page in `08 Prioritization/` is the source of truth for the rest of the session, get the list right before touching frameworks.

### 3a. Open with the prompt

Ask the user, plainly:

> *"What are your current priorities you want to start to think about this week? Just give them to me as they come, one line each, no order, no formatting. We'll sort them after."*

Let them paste, type, or dictate. Capture every item exactly as said. Don't tidy phrasing yet.

If they stall, prompt once: *"Anything else on your mind, even the half-formed ones?"* Then stop pushing.

### 3b. Tie each item to a project (one at a time)

For **each captured item**, check it against the project list from Phase 1. Try to match by keyword (project name in the item, recognisable people, recognisable workstreams). Then run a short clarification:

**If a likely project match exists:**

Use `AskUserQuestion`:

> *"Sounds like this might tie to **`[[11 Projects/<match>]]`**: is that right?"*
> - **Yes, that project**
> - **No, standalone for now**
> - **Different project** → ask which, multi-select from the project list

**If no obvious match:**

Use `AskUserQuestion`:

> *"I don't see an existing project for this. Want to spin one up, or keep it standalone?"*
> - **Standalone for now** (Recommended for one-offs)
> - **Create a new project page** → hand off to the **New Project Skill** ([[00 Skills/11 - New Project Skill]]). When it returns, link the item to the new project.
> - **Skip, I'll decide later**

Keep this lightweight. The goal is one of three outcomes per item: `→ [[11 Projects/<existing>]]`, `→ Standalone`, or `→ [[11 Projects/<newly-created>]]`.

Do not push the user to create projects. If they say no twice, stop offering.

### 3c. Surface anything I noticed in the vault

Pull up the candidate suggestion list from Phase 1. If it's empty, skip this step entirely. If not, open with one framing line, *flagging, not pushing*:

> *"Before we lock the list, I noticed a few things in the vault that look due-soon or unresolved. Want me to walk through them? Say no and we move on, no pressure."*

If they say yes, go through them one at a time. For each candidate, surface it with the source so the user can verify it's real:

> *"In `[[11 Projects/Q3 Roadmap/CLAUDE.md]]` there's a TODO: 'Send Priya the pilot result by 2026-06-05.' Should this be on this week's list?"*

Use `AskUserQuestion`:

- **Yes, add it** → append to the captured list, tied to the source project automatically.
- **No, skip** → drop it silently. Don't ask why.
- **Already covered** → the user thinks it overlaps with something they already named; ask which item and merge a note onto that line (`(also covers: <source ref>)`).

Run through the list once, top to bottom. **Do not loop, do not re-pitch items, do not editorialise.** If they skip three in a row, ask: *"Want me to stop surfacing these and just move on?"* and respect the answer.

This step is the only place the skill is allowed to propose items the user didn't say out loud. The rule is strict: *every* surfaced item must point at a real source file, a TODO, a date, a commitment in the decision log, an unresolved entry from last week. Nothing invented. If you can't cite a file and line, don't surface it.

### 3d. Write the captured list to the page

Once every item (user-given + accepted suggestions) has a project tie (or "Standalone"), create the page using the Phase 6 structure with only the frontmatter, the title, and the `## Items captured` block filled in. Leave the session block for later.

For items that came from the Phase 3c suggestion pass, annotate the line with the source so future-you knows where it came from:

```markdown
- Send Priya the pilot result → [[11 Projects/Q3 Roadmap]] *(surfaced from `CLAUDE.md` TODO, due 2026-06-05)*
```

Show the saved file as a wikilink so the user can open it: `[[08 Prioritization/W23 2026 - Backlog Triage.md]]`. This is now the source of truth. From here on, refer to it rather than holding the list in conversation memory.

## Phase 4: Choose the Framework

The captured list is now on disk. Time to triage it.

**AskUserQuestion**: include a one-line description per option so the user knows what they're picking:

> **Which framework do you want to triage by?**
> - **Do / Sequence / Delegate / Decline** (Recommended, matches the vault template)
>   *Sorts each item by impact and effort. Do = high impact, low effort, this week. Sequence = high impact, high effort, roadmapped with a real slot. Delegate = low impact, low effort, someone else owns it. Decline = low impact, high effort, the defensible no.*
> - **Eisenhower** (Urgent × Important)
>   *Classic 2×2 by urgency and importance. Do = urgent + important. Schedule = important, not urgent. Delegate = urgent, not important. Drop = neither. Best when deadlines are doing most of the sorting.*
> - **Freeform ranked list**
>   *No quadrants, just a top-to-bottom ranking. One line of "why this rank" per item. Best when the list is small or the items aren't comparable on impact/effort.*

The choice determines the question set in Phase 5 and the grid in Phase 7.

## Phase 5: Run the Framework Questions

For **each item** in the working list, ask a short fixed set of questions. Three to four prompts max. These are diagnostic, capture the answer, propose a placement, confirm, move on. Do not open a wider conversation about strategy.

After each item, summarize back the quadrant assignment in one line: *"→ **Do**: `<one-line reason>`"*. Then move to the next.

**Capture the user's answers verbatim, not paraphrased.** This is the rationale we'll write to the page, future-you needs to be able to read it weeks later and remember *why* this item landed where it did. If the user says "Marcus is on holiday, anyone else moving it is going to flounder," write that, not "ownership constrained." Their words, their reasoning.

### Do / Sequence / Delegate / Decline

1. *"What outcome does this unlock this week?"* (value)
2. *"What's the cost of delaying it 7 days?"* (urgency)
3. *"Are you the only person who can move it?"* (ownership)
4. Propose: *"Sounds like **Do** / **Sequence** / **Delegate** / **Decline**: agree?"* Confirm or correct.

Map the quadrants to the template language:
- **Do** = high impact, low effort, this week
- **Sequence** = high impact, high effort, roadmapped with a real slot
- **Delegate** = low impact, low effort, someone else owns it (name them + level if known)
- **Decline** = low impact, high effort, defensible no

### Eisenhower

1. *"Does this drive a goal you've committed to?"* (important)
2. *"Does it have a hard deadline this week?"* (urgent)
3. Propose placement: Do / Schedule / Delegate / Drop. Confirm.

### Freeform ranked list

1. *"If you could only finish one thing this week, would it be this?"*
2. *"What rank, top to bottom?"*, collect a position.
3. *"One line on why it sits at that rank, what makes it #N and not #N+1?"* Capture the rationale.

Once every item has a placement, ask the closing **session-level rationale** question:

> *"Stepping back from the individual items, what's the through-line this week? Any tradeoffs you made that might look weird to you in three weeks? Anything you're deliberately not doing that someone might ask about?"*

Capture this verbatim too. It goes in the `### Why this shape` block in Phase 6. This is the bit that pays off when you come back in October and ask "why on earth did I delegate that?": the per-item rationale tells you the local reasoning, this section tells you the session-level logic.

Then move to Phase 6.

## Phase 6: Page Structure

Phase 3c already created the file with frontmatter and the `## Items captured` block. Phase 6 is about appending the session block (triage notes + grid) underneath.

### New file structure (reference: built across Phase 3c + Phase 6)

```markdown
---
type: note
module: "08 Prioritization"
session: "Ongoing"
framework: <chosen>
status: active
week: 23
year: 2026
iso: 2026-W23
tags: [prioritization, weekly, backlog-triage]
publish: true
---

# W23 2026 - Backlog Triage

## Items captured
- <item> → [[11 Projects/<project>]] *(if project-sourced)*
- <item> → Standalone
...

## Session: 2026-06-03 14:22
Framework: Do / Sequence / Delegate / Decline

### Triage notes
Per-item rationale, captured in the user's words. Future-you reads this to remember the call.

- **<item>** → **Do**
    - *Outcome:* "<verbatim>"
    - *Cost of delay:* "<verbatim>"
    - *Ownership:* "<verbatim>"
    - *Call:* "<one-line confirming sentence from the user, if they added one>"
- **<item>** → **Sequence**
    - *Outcome:* "<verbatim>"
    - ...

### Why this shape
Session-level logic. The through-line, the tradeoffs, the deliberate omissions. One paragraph in the user's voice. Captured at the end of Phase 5.

> "<verbatim session-level rationale>"

### Grid backlog
<2×2 from Phase 7>
```

### Existing-week file

- Keep the original `## Items captured` block intact.
- Add new items under a fresh `## Items added: YYYY-MM-DD` block.
- Append a new `## Session: YYYY-MM-DD HH:MM` block with its own `### Triage notes`, `### Why this shape`, and `### Grid backlog` underneath.

Never edit prior session blocks. Each session stands as its own record, its captured items, its rationale, and its grid all locked together. That's what makes the page useful months later.

## Phase 7: Grid Backlog

Render at the bottom of the session block.

### Do / Sequence / Delegate / Decline (default)

|              | Do this week | Sequence later |
|--------------|--------------|----------------|
| **Own**      | Do           | Sequence       |
| **Hand off** | Delegate     | Decline        |

Drop items into the matching cell. One per line. Add the project wikilink if the item was project-sourced.

### Eisenhower

|                   | Urgent   | Not urgent |
|-------------------|----------|------------|
| **Important**     | Do       | Schedule   |
| **Not important** | Delegate | Drop       |

### Freeform

Skip the 2×2. Render a numbered ranked list under `### Ranked backlog`.

## Phase 8: Confirm

After saving the session block, show the user:

1. **Page updated** at `[[08 Prioritization/W23 2026 - Backlog Triage.md]]`: captured list, triage notes, and grid all in one place.
2. If an existing week page was appended to, mention: *"Appended a new session, prior items and sessions are intact."*
3. If any new project pages were created in Phase 3b, list them as wikilinks so the user can open them.
4. Suggest the next move only if the grid points to one: a Delegation Brief for items in **Delegate**, or a C.O.R.E. message for items in **Decline**. Don't push it, just name the option.

## House Rules

- **No em dashes or en dashes.** Vault convention. Commas, colons, periods, parens. The `→` glyph is fine.
- **Don't invent items, but do surface what's in the vault.** Two different things:
    - *Fabrication* (forbidden), making up a task the user didn't say and the vault doesn't show. Never do this.
    - *Surfacing* (encouraged, once per session, in Phase 3c), pointing at a real TODO, date, or commitment that already exists in `11 Projects/`, `09 Decision Log/`, or last week's triage page, and asking *"should this be on the list?"* Every surfaced item must cite its source file. Flag, don't push. Three skips in a row → stop surfacing for the session.
- **Don't overwrite prior sessions.** Same week → append. Always.
- **Wikilinks for project-sourced items.** Use `[[11 Projects/<project>]]` so the page is navigable in Obsidian.
- **`publish: false`** on every generated page. Weekly triage is private.

## Reference Reads

- `00 Skills/02 - Audience Map Builder Skill.md`: phase pattern, `AskUserQuestion` usage.
- `08 Prioritization/_Template - Backlog Triage.md`: quadrant language to reuse verbatim.
- `08 Prioritization/EXAMPLE - Backlog Triage (Churn Week).md`: worked example of the D/S/D/D voice.
