---
type: skill
module: "00 Skills"
session: "Session 1"
framework: "Audience Mapping"
tags: [skill, audience-mapping, automation]
publish: true
---

# Skill: Audience Map Builder

Interview the user about a stakeholder and produce a populated Audience Map in `02 Audience Mapping/`. Two modes: a lean 3-round capture (~5 min) by default, with an opt-in deep pass (5 rounds, ~10 min) for the stakeholders that matter most.

## When to Use

- User wants to map a new stakeholder
- User says something like "let's map Sarah" or "I need to understand my new CFO better"
- An existing map feels stale and the user wants to refresh it
- During Session 1, when working through the audience mapping framework

## How It Works

1. Scan the vault for context (silent)
2. Round 1 sets the relationship type, which branches every later round
3. Run the lean 3-round interview
4. Offer to go deeper (Rounds 4 and 5) or wrap
5. Generate the map in the user's voice
6. Review, edit, save

If a map already exists for this stakeholder, ask whether to refresh in place or start fresh in a new file.

## Phase 1: Scan the Vault

Before asking anything:

```bash
# Pull the user's own profile so Claude knows who is asking
cat "01 Leadership Profile/Leadership Profile.md" 2>/dev/null

# See which maps already exist
ls "02 Audience Mapping"/*.md 2>/dev/null | grep -v "_Template\|EXAMPLE\|README"
```

Record:
- The user's name, role, and their stated top 3 stakeholders (from the profile)
- Existing audience maps, so you can skip duplicates and reference siblings
- Whether the stakeholder being mapped is in the user's top 3 (mention it back if yes; it raises the stakes of getting this right)

Do not narrate the scan. Just use what you learn.

## Phase 2: Interview

Conversational. After each round, **briefly summarize what you captured** so the user can correct anything before you move on. Probe once on thin answers, then move on. Don't interrogate.

---

### Round 1: Gateway

Ask for the basics, then use **AskUserQuestion** for the relationship. This is the branching point for every later round.

Ask:
- **Their name?**
- **Their role or title?**

Then AskUserQuestion:

> **What's your relationship to them?**
> - **Direct report** (you manage them)
> - **Boss or skip-level** (they manage you, or theirs)
> - **Peer** (no reporting line either way: leadership team, cross-functional partner, anyone you work alongside)

Record the answer as the branch for the next two rounds. Map onto the template field as: report / boss / peer.

If the stakeholder appears in the user's Leadership Profile top 3, say so back: "Noting: they're one of your top 3 stakeholders, so we'll do this carefully."

---

### Round 2: Who they are + what they care about

Start with **who they are as a person**: personality, working style, how they like to be communicated with. Then move to what's on their plate. Don't open with fears or "what wakes them up at 3am"; ground in the person first.

**Part A: Who they are**

> *"Beyond the title, tell me who they actually are. How would you describe their personality and how they show up at work? Decisive or deliberative? Warm or transactional? Big-picture or detail-first?"*

> *"How do they like to be communicated with? Not format yet (that's the next round). More the style: direct or diplomatic, data-led or story-led, fast and punchy or slow and considered?"*

Probe once if the answers are thin: *"Give me an example. Last time you saw them at their best, what did that look like?"*

**Part B: What they care about right now**

> *"Now, what's actually on their plate? The 2-3 things they're most focused on this quarter. Not job description, what's live for them right now, and which one is the acute one this week."*

Then add **branch-specific probes** based on Round 1. Pick the 2-3 that fit; don't ask all of them.

**If direct report:**
- What projects are they owning right now? Which one are they most invested in?
- Where are they in their career arc? What's the next role or scope they're working toward?
- What are they trying to learn or grow into? Where do they want more autonomy you haven't given them?
- What energises them at work, and what drains them?
- What's the personal context worth knowing? (career stage, life stage, anything shaping how they show up right now)

**If boss or skip-level:**
- What's their mandate? What were they put in this seat to do?
- What are the key things they care about in the strategy right now?
- What's their objective for this quarter or this year? What does success look like for them?
- What do they keep coming back to in conversations with you? What's the topic they always pull toward?
- Where do they focus their attention? What gets the airtime, and what do they delegate or tune out?

**If peer:**
- What function or department do they own? (marketing, product, finance, ops, etc.)
- What's their area of expertise, the thing they're known for, the lens they bring?
- What do they care about most? What do they talk about, again and again?
- How do they approach problems? Analytical, intuitive, consensus-led, fast-and-loose?
- Where do the two of you already work together closely? Where *could* you work closer if you chose to?
- When do you actually interact with them: standing forums, ad hoc, only when something's on fire?

Summarize back: "So the person: X, Y. The things on their plate: A, B, C. The acute one right now is B. Got it."

---

### Round 3: Communication preferences + what shuts them down

This is the highest-leverage round. The maps in the vault are only useful because they capture *triggers* and *voice patterns*, not just priorities.

Note the shift from Round 2: Round 2 captured the *personality-level* style (direct vs diplomatic, data vs story). Round 3 is the *tactical* detail: channel, format, tone, structure, timing. How to actually land a message with them. Open with: *"Now the tactical side. When you actually send them something, what works?"*

**Part A: How they consume information**

Start with **AskUserQuestion** for the primary channel:

> **What's their preferred channel for important stuff?**
> - **One-pager / written memo**
> - **Slides**
> - **Slack or async written**
> - **Email**
> - **Verbal / in a meeting**

Then probe across the dimensions below. Pick the 3-4 that haven't been answered yet; don't ask all of them. Try to capture both what they *prefer* and what they actively *reject*.

- **Format:** Slides or prose? Long memo or one-pager? Bullets or paragraphs? Big decks or short docs?
- **Tone and register:** Casual or formal? Buttoned-up or playful? Emoji and gifs, or strictly text? First names or full titles?
- **Structure:** "So what" first, or do they want the build-up and reasoning before the answer? (Most senior people: "so what" first. Confirm anyway, some explicitly want the build.)
- **Length tolerance:** One screen? Three slides? A full memo if the topic warrants it? Where's the line where they tune out?
- **Data density:** Headline number only, or do they want the model and assumptions behind it? Charts or tables? Raw data or pre-chewed?
- **Sync vs async:** Prefer to read on their own time and come back, or talk it through live in the room?
- **Timing and cadence:** Morning brain or end-of-day brain? Want prep time before a decision, or decide in the room? Any standing slots they protect?
- **Decision pattern:** Do they decide on the spot, or sleep on it? Do they want a recommendation, or options to choose from?

Summarize back what you captured before moving on: *"So: channel is X, format is Y, tone is Z, they want the so-what first, length tolerance is roughly N. Anything I got wrong?"*

**Part B: What shuts them down**

Then the trigger question. Push for a story:

> *"Tell me about a time a conversation with them went sideways. What were you saying? What did they do (push back, go quiet, redirect, get short)?"*

Listen for:
- Specific phrasing that costs trust ("when she says X, she means Y")
- Behavioral patterns (Marcus goes silent rather than pushing back; Sarah says "the data is wrong" when she means "explain the gap")
- Topics or framings that reliably misfire

If they can't think of one, ask: *"What's a phrase or framing you've learned not to use with them?"*

---

### Decision point: lean or deep?

After Round 3, ask plainly:

> "I have enough to write a solid lean map. Want to go two rounds deeper into great outcome, current state, personal detail, and voice notes for Claude? Or save what we have?"

If lean: skip to Phase 3 with the sections from Rounds 4 and 5 left thin or empty.

If deep: continue.

---

### Round 4 (deep mode): Great outcome + current state of the relationship

> *"They walk out of a meeting with you happy. What just happened? Specifically: what did they leave with? One number, one decision, one owner?"*

Then:

> *"Where do you stand with them right now? Recent win, recent friction, anything you owe them or any open loop?"*

Capture both. If an open loop surfaces, just record it; do not offer to scaffold a draft (the user can run the Stakeholder Message skill separately).

---

### Round 5 (deep mode): Personal detail + voice notes for Claude

Two prompts, both important, both quick:

> *"One small human thing about them. Kid's soccer team, cycling, a phrase they always open meetings with, the running injury. Not for manipulation, for memory."*

> *"If I were drafting a message to them tomorrow, what should I match and what should I avoid? Sentence length, words they use, words to never use, openings that work, openings that don't."*

The voice-match answer is what makes the resulting Stakeholder Drafts actually sound right. Don't skip it in deep mode.

---

## Phase 3: Generate the Map

**Filename:** `<Name> (<Role>).md` in `02 Audience Mapping/`. Match the EXAMPLE pattern. So `Sarah (CMO).md`, not `EXAMPLE - Sarah.md`, not `audience-map-sarah.md`. If a file with that name already exists, append a short qualifier rather than overwrite (e.g. `Sarah Chen (CMO).md`).

**Frontmatter** (pre-filled):

```yaml
---
type: note
module: "02 Audience Mapping"
session: "Session 1"
framework: "Audience Mapping"
status: active
stakeholder: <First Name>
stakeholder_role: <Role>
tags: [audience-mapping, <name-lowercased>]
publish: true
---
```

`publish: false` because real stakeholder notes are private. Templates and EXAMPLEs publish; filled-in maps do not.

**Body** (match the template structure exactly, in this order):

```markdown
# Audience Map: <Name> (<Role>)

## Who they are

- **Name:** <full name if known, else first name>
- **Role / title:** <role>
- **Relationship to you:** <one sentence, not just the bucket, the texture. Example: "Peer on the leadership team. Owns the revenue narrative I support with data.">

## Personality and working style

<from Round 2 Part A. 2-4 bullets capturing personality (decisive / deliberative, warm / transactional, big-picture / detail-first) and the personality-level communication style (direct vs diplomatic, data-led vs story-led, fast vs considered). Use the user's words.>

## What they care about most

<from Round 2 Part B. Bulleted list of the 2-3 priorities. One line each. Concrete, not abstract. If one of them is the acute focus this week, mark it: "**(acute right now)**" at the end of that bullet.>

## How they consume information

- **Channel:** <preferred channel from Round 3, memo, slides, Slack, email, verbal>
- **Format:** <slides vs prose, deck vs one-pager, bullets vs paragraphs>
- **Tone and register:** <casual or formal, buttoned-up or playful, emoji or strictly text>
- **Structure:** <"so what" first vs build-up, with a one-line gloss if useful>
- **Length tolerance:** <one screen / three slides / full memo if warranted>
- **Data density:** <headline only vs model behind it, charts vs tables>
- **Sync vs async:** <read on their own time vs talk it through live>
- **Timing and cadence:** <morning vs end-of-day brain, prep time vs decide-in-the-room, any standing slots>
- **Decision pattern:** <decides on the spot vs sleeps on it, wants a recommendation vs options>

Leave blank any dimension the user didn't speak to. Don't invent.

## What makes them shut down

<bulleted list from Round 3. Specific phrasings, specific behaviors. This is where you write down Sarah's "the data is wrong" reframe or Marcus's "goes silent" pattern.>

## What a great outcome looks like for them

<from Round 4 if deep mode; one line. If lean mode, leave a placeholder: "_To fill in, what does success look like for them after a meeting with you?_">

## Current state of the relationship

<from Round 4 if deep mode. Open loops, recent friction, recent wins. If lean mode, placeholder.>

## Personal detail

<from Round 5 if deep mode. One bullet, human. If lean mode, placeholder.>

## Notes for Claude

<from Round 5 if deep mode. Voice patterns, openings to use, openings to avoid, language to match. If lean mode, placeholder.>
```

**Generation rules:**

- **Don't fabricate.** Thin answer → thin section. Never invent a personal detail, a trigger phrase, or a relationship texture. If a section is empty, leave a one-line italic placeholder asking the user to fill it later. Better an empty section than a fake one.
- **Use their words.** If the user said "she's a cyclist who thinks in watts," write that. Don't rewrite as "she has an athletic background." Mirror their phrasing.
- **Lead each section with the punch line.** Look at `EXAMPLE - Sarah (CMO).md` and `EXAMPLE - Marcus (Data Engineer).md`. Sections open with the headline, not preamble.
- **No em dashes or en dashes anywhere.** Vault convention. Commas, colons, periods, parens. The `→` glyph is fine.

## Phase 4: Review & Confirm

Show the full generated map. Ask:

> "Here's the map. Anything to change, add, or sharpen before I save it?"

Make targeted edits to the sections the user flags. Don't regenerate the whole document. Loop until they say it's good.

Write the file only after explicit confirmation. Save to `02 Audience Mapping/<Name> (<Role>).md`.

## Phase 5: Wrap

After saving, tell the user:

1. **Map saved** at `[[02 Audience Mapping/<Name> (<Role>)]]`
2. **It's set to `publish: false`**: your real stakeholder notes stay private even if you turn on Obsidian Publish later.
3. **Revisit when the relationship shifts.** Audience maps go stale fast. The version that was true in Q1 will be wrong by Q3 if you don't update.
4. If they did a lean map, mention: "You can run this skill again later in deep mode to fill in the great-outcome, personal-detail, and voice-notes sections."

Do not offer to scaffold notes in other folders. Keep this skill focused on the map.
