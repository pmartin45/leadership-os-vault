---
type: skill
module: "00 Skills"
session: "Pre-Work"
framework: "Leadership Profile"
tags: [skill, leadership-profile, automation]
publish: true
---

# Skill: Leadership Profile

Walk the user through filling in `01 Leadership Profile/Leadership Profile.md` by interviewing them section by section, then writing their answers into the file. The result is a complete Leadership Profile that grounds every Claude session.

## When to Use

- User just finished `Brain Setup` and is doing the Pre-Work bootcamp
- `01 Leadership Profile/Leadership Profile.md` is still the empty template (placeholder fields, `status: template`)
- User explicitly asks to fill in, set up, or update their Leadership Profile
- An existing profile is stale and the user wants to refresh it (role changed, new team, new stakeholders)

If the file already has real content, ask whether they want to **start fresh** or **update section by section**. Default to update. Never silently overwrite work the user already did.

## How It Works

1. Read `01 Leadership Profile/Leadership Profile.md` to see current state
2. Read `01 Leadership Profile/EXAMPLE - Alex Park.md` so you have the reference for what "done" looks like
3. **Offer the CV option.** If the user drops a CV / resume / LinkedIn export into `01 Leadership Profile/`, read it and use it as background context for the interview
4. Interview the user in 6 rounds, one per section of the profile
5. After each round, **write that section into the file immediately** so progress is preserved if the session is interrupted
6. After the last round, flip the frontmatter `status: template` to `status: active` and show the user the finished file

**Pacing:** Group related sub-questions naturally. It's fine to ask 3-4 at once if they flow together. If an answer is thin, probe once, then move on. The user told you to guide them, so guide, don't interrogate.

**Tone:** The user is filling this in by talking to you. They can write fragments, half-sentences, "you know what I mean". Your job is to turn that into clean prose in their voice. Mirror their language. Don't sanitize "I hate when people send me 12-bullet status dumps" into "I prefer concise communication."

## Phase 1: Orient

Before asking anything:

1. Read the current `Leadership Profile.md`, noting which fields (if any) already have real content
2. Read `EXAMPLE - Alex Park.md` and keep it in mind as the bar for specificity and tone
3. If the user has a `CLAUDE.md` at the vault root from Brain Setup, skim it. You may already know their name, role, voice notes, and goals. Use what's there as a starting point and confirm rather than re-asking from scratch.
4. **Check `01 Leadership Profile/` for a CV / resume.** Look for files like `CV.pdf`, `Resume.docx`, `linkedin.pdf`, anything that looks like a resume export. If one exists, read it before the interview. If not, you'll offer the option below.

Open the conversation with something like:

> "I'm going to walk you through your Leadership Profile. Six short sections. Answer in whatever form is easiest. Fragments are fine, I'll write it up cleanly in your voice. I'll save to the file after each section so nothing gets lost.
>
> One optional setup step first: if you have a CV, resume, or LinkedIn PDF handy, drop it into the `01 Leadership Profile/` folder and I'll read it for background. It helps me ask sharper questions because I'll already know your history (past roles, accomplishments, what you've built). Totally optional. Want to do that, or skip and dive in?"

**If they want to add a CV:**
- Wait for them to drop the file in. Common formats: `.pdf`, `.docx`, `.md`, `.txt`. LinkedIn exports usually arrive as PDF.
- Once it's there, read it with the `Read` tool.
- Briefly summarize back what you learned: "Okay, I see [X years in data / Y industry / past roles at A, B, C / notable: Z]. That gives me a baseline. Let's use it to make the interview faster."
- **Do not auto-fill profile fields from the CV.** Use it as background only. The profile captures who they are *now*. The CV is history, not the current snapshot.
- Where the CV is genuinely useful: framing questions ("I see you came from finance into data. Does that shape how you talk to Priya the CFO?"), spotting accomplishments they might be underselling, and calibrating the voice round (their bullet points reveal a lot about how they write).

**If they skip the CV:** No problem. Move straight to Round 1. Don't re-ask later. They made their choice.

## Phase 2: Interview (6 Rounds)

After each round: **summarize back what you captured**, let them correct, then write that section to `01 Leadership Profile/Leadership Profile.md` before moving on.

---

### Round 1: Basics

Ask:
- **Your name** (if not already known from CLAUDE.md)
- **Role / title**
- **Company and industry**: what does the company do, roughly how big, what stage (startup / scale-up / enterprise / public)
- **Team size**
- **Team structure**: who reports to you, what do they do, any matrix / dotted-line relationships

**Goal:** Concrete enough that someone reading this knows what you actually run. "8 people: 4 data scientists, 3 analysts, 1 ML engineer" beats "small data team."

**Write:** Fill in the `## Basics` section.

---

### Round 2: Top 3 Stakeholders

Frame it: "Who are the three people whose buy-in shapes your quarter? Not your full org chart, just the three that move the needle."

For each stakeholder, ask:
- **Name and role**
- **What they care about most**: one line. What they're optimizing for, what makes them happy, what makes them push back.
- **(Optional) Any tell**: a phrase they use, a behavior pattern, a known sensitivity

**Probe if thin:** If they list someone but can only say "wants the numbers," push once: "When she pushes back, what does she say?" Specifics here directly shape every draft you'll help them write later.

**Goal:** Each stakeholder line is so specific you could write a message in their voice. Look at the Alex Park example: "Says 'the data is wrong' when the gap between her gut and the numbers is not explained" is the bar.

**Write:** Fill in the `## Top 3 stakeholders` section.

---

### Round 3: Top 3 Current Challenges

Frame it: "Three things on your plate this quarter that actually matter. Not the inbox, the substance. The things that, if you solved them, would change your quarter."

Ask:
- **Challenge 1:** What is it, and why is it stuck or hard?
- **Challenge 2:** Same.
- **Challenge 3:** Same.

**Probe if generic:** "Stakeholder alignment" is too vague. Push: "Aligned on what? With who? What does the blocker look like in practice?"

**Goal:** Each challenge is concrete enough that Claude can spar on it without asking five clarifying questions. "Marketing keeps relitigating segment definitions, three meetings no decision" beats "stakeholder alignment issues."

**Write:** Fill in the `## Top 3 current challenges` section.

---

### Round 4: Operating Context

Ask:
- **Company stage**: startup / scale-up / enterprise / public. Add headcount and funding stage if relevant.
- **Where your function sits in the org**: who you report to, who you used to report to if it changed recently, any structural quirks
- **Key constraints**: headcount frozen? tooling locked? political? regulatory? what's the thing you can't move?

**Goal:** Context Claude needs to give realistic advice. "Headcount frozen until Q3" stops Claude from suggesting "just hire someone."

**Write:** Fill in the `## Operating context` section.

---

### Round 5: How I Write and Speak

This is the section that controls how Claude drafts in their voice. Don't rush it.

Ask:
- **Default register**: formal / direct / warm / dry / something else. Which one is closest to how they *actually* write, not how they wish they wrote.
- **Words and phrases they use a lot**: give 3-5 examples. The connective tissue of their writing. ("Here's where we are." "The trade-off is…" "What I'd recommend.")
- **Words and phrases they never use**: corporate-speak they refuse, "just circling back," "synergy," etc.
- **Their version of a great message**: one or two sentences describing what "good" looks like when it comes out of their hands. (e.g., "One screen. Opens with the headline. Closes with a specific ask.")

**If they struggle:** Ask them to paste or recall a message they wrote recently that they were proud of. Reverse-engineer the voice from a real example.

**Goal:** Specific enough that Claude can pass a Turing test on a 3-sentence Slack message in their voice.

**Write:** Fill in the `## How I write and speak` section.

---

### Round 6: Notes for Claude

Frame it: "Anything else Claude needs to know to be useful to you specifically? Things that don't fit the categories above but shape how I should think with you."

Prompt with examples:
- Remote-first team across time zones?
- New in role (first 6 months) vs. tenured?
- Reports to a board chair who reads prose, not decks?
- Personal context that matters (parent, caregiver, training for something, faith)?
- Tools your team lives in (Linear, Notion, Jira, Slack channels you watch)?

**Goal:** Loose bullets. The stuff that would normally come up in the third Claude session. Capture it now so it grounds from session one.

**Write:** Fill in the `## Notes for Claude` section.

---

## Phase 3: Finalize

After Round 6:

1. **Update the frontmatter:** change `status: template` to `status: active`. Leave everything else as-is.
2. **Show the finished file** to the user, full content, top to bottom.
3. Ask:

   > "Here's your Leadership Profile. Read it through. Anything you want to change, sharpen, or remove before we call it done?"

4. **Revisions:** Make targeted edits to whatever they call out. Don't regenerate the whole document. Loop until they say it's good.

## Phase 4: Next Steps

Once the user confirms:

1. **Profile is live.** It's the context every Claude session pulls from. Paste it (or reference it) at the start of any sparring session.
2. **Update it when reality changes**: new role, new team, new stakeholders, new challenges. A stale profile makes for stale sparring.
3. **Next stop in the Pre-Work:** the two pre-watch videos (*Why Smart Data Leaders Don't Get Invited to the Room*, *Saying No Without Losing Trust*).
4. **First framework you'll use it on:** Audience Mapping (`02 Audience Mapping/`). The three stakeholders you just named are the first three maps you'll build in Session 1.

## Critical Rules

- **Write incrementally.** Update the file after each round, not at the end. If the session crashes, the user keeps everything they answered.
- **Use their words.** If they said "I hate decks, everything is a memo," write that. Don't rewrite it as "I prefer memo-style communication."
- **Never fabricate.** Thin answer = thin section. Better to leave a placeholder note than invent stakeholder details.
- **Don't touch the EXAMPLE file.** `EXAMPLE - Alex Park.md` is reference material. Read it for tone calibration; never edit it.
- **Preserve the frontmatter shape.** Keep `type`, `module`, `session`, `framework`, `tags`, `publish` exactly as they were. Only change `status: template` → `status: active` at the end.
