---
type: skill
module: "00 Skills"
session: "Session 1"
framework: "Influence Strategy Canvas"
tags: [skill, influence, stakeholder-drafts, automation]
publish: true
---

# Skill: Influence Plan Builder

Plan a specific influence move on a specific person, frame the ask in *their* world (not the user's), and produce an Influence Plan in `03 Stakeholder Drafts/` with the actual message ready to send. Cross-link the audience map and the project so the move is visible from every angle.

The user comes in with someone to influence: an exec to convince, a peer to get on board, a budget to unlock, a roadmap shift to land. Your job is to find the one incentive or pain point that makes a yes rational for *them*, and build the smallest first move that opens the door.

## When to Use

- User says "I need to influence X", "help me get Y on board with Z", "I need a yes from `<person>`", "let's plan an influence move"
- User is heading into a 1:1, a leadership meeting, or a forum where they need to move a specific person on a specific decision
- An ask has already failed once and the user wants to come back at it with a better frame
- During Session 1 or 2, when working through how to move things without authority

**Do not start drafting until the person and the ask are named.** Ground first. An influence plan without a named person and a named ask is a wish list.

## How It Works

| # | Phase | What gets locked |
|---|-------|------------------|
| 1 | **Scan** | Vault context, silently |
| 2 | **Goal** | What to move, by when, why now |
| 3 | **Person** | Stakeholder + their audience map |
| 4 | **Project** | Optional link from `11 Projects/` |
| 5 | **Bridge** | The ask in *their* language (highest-leverage phase) |
| 6 | **Friction** | Surface objection, real objection, cost of yes |
| 7 | **Strategy** | One of five, justified against the map |
| 8 | **First yes** | Smallest visible step this week |
| 9 | **Draft** | The actual message, in their format, in your voice |
| 10 | **Generate** | The Influence Plan note |
| 11 | **Review** | Sharpen, then save |
| 12 | **Cross-link** | Audience map + project, additive only |
| 13 | **Wrap** | File list + follow-up reminder |

If an influence plan already exists for this person on this topic, ask whether to refresh in place or start a fresh dated file.

## Phase 1: Scan the Vault

*Silent. Do not narrate.*

```bash
# The user's voice and stakeholders
cat "01 Leadership Profile/Leadership Profile.md" 2>/dev/null

# Existing audience maps (drop README/EXAMPLE/Template noise)
ls "02 Audience Mapping"/*.md 2>/dev/null | grep -v "_Template\|EXAMPLE\|README\|^00 "

# Existing influence plans and drafts
ls "03 Stakeholder Drafts"/*.md 2>/dev/null | grep -v "_Template\|EXAMPLE\|README\|^00 "

# Existing projects (drop the template)
ls -d "11 Projects"/*/ 2>/dev/null | grep -v "(PROJECT TEMPLATE)"

# Reference: the Influence Plan template
cat "03 Stakeholder Drafts/_Template - Influence Plan.md"
```

**Pin:**

- The user's voice notes from the Leadership Profile
- Audience maps available, especially the user's top stakeholders
- Any prior influence plans on the same person or topic
- Real projects (so any project link is grounded in reality)

## Phase 2: Lock the Goal

*One short round. Capture it tightly.*

**Ask:**

> "In one sentence, what are you trying to move? Not 'get exec buy-in', something specific. A pilot approval, a roadmap shift, a budget unlock, a green light to kill a project, a headcount, a decision date."

**Push** (if vague):

> "On board with what, specifically? What is the actual decision, resource, or permission you need from them?"

**Then ask the timing:**

> "By when do you need this, and why now? What changes if the yes comes in two weeks vs two months?"

**Summarize back:** *"Goal: `<one sentence>`. By `<date>`. Why now: `<one sentence>`."*

If timing is fuzzy, leave a placeholder. Better an honest gap than a confident lie.

## Phase 3: Lock the Person

*Branch on existing audience map vs no map yet.*

Build options dynamically from the audience maps found in Phase 1. Show up to 4 candidates: the user's top 3 stakeholders, plus anyone mentioned in their opening.

**AskUserQuestion:**

> **Who are you trying to influence?**
> - **`<Name 1>` (`<Role>`)** [from existing map]
> - **`<Name 2>` (`<Role>`)** [from existing map]
> - **`<Name 3>` (`<Role>`)** [from existing map]
> - **Someone else / no map yet**

### If an existing map

Read it fully. **Pin:**

- What they care about most (the priorities the influence frame must connect to)
- What makes them shut down (language and framings the move must avoid)
- How they consume information (format, channel, length tolerance)
- Voice notes: openings to use, openings to avoid, language to match
- Any open loops or recent friction in the relationship state

**Say back, in one line:** *"Okay, planning for `<Name>`. They own `<priority>`. They shut down on `<trigger>`. The move will be `<format>`."*

### If "someone else / no map yet"

Pause. Offer two paths:

> "Either we run the Audience Map Builder first (5 minutes, lean mode is enough), or you give me the basics inline: name, role, what they own, what they care about most, what shuts them down. Which?"

If inline, capture those five fields and keep going. If map first, hand off to **Audience Map Builder** and resume here when the map is saved. An influence plan without a map under it is generic.

## Phase 4: Lock the Project (Optional)

**AskUserQuestion:**

> **Is this influence move tied to a project?**
> - **`<Project 1>`** [from `11 Projects/`]
> - **`<Project 2>`** [from `11 Projects/`]
> - **No project, this is a standalone influence task**

If a project is named, read its `CLAUDE.md`. **Pin:**

- The project's prime directive
- Where this influence move sits in the project's process
- Any other stakeholders on the project who care about this decision

If no project, that is fine. The plan will not have a project link. Move on.

## Phase 5: Translate the Ask Into *Their* World

> **This is the highest-leverage phase in the whole skill.** Same ask, two frames. To the head of marketing, "this enhances our product features" is a yawn. "This reduces our advertising spend by X" is a different conversation. We need the second framing.

Three short rounds. Land all three before moving on.

### Round A: What they own

**Ask:**

> "What do they own that this ask touches? A number on their dashboard. A team. A timeline. A budget line. A relationship. A reputation. Be specific. What is the thing of theirs that this move makes bigger, smaller, easier, or harder?"

**Push** (if user answers in their own language, e.g. "it improves our data quality"):

> "That is what it does for *you*. What does it do for *them*? Pull from their audience map. What do they wake up worrying about? What is the metric on their slide at the QBR?"

### Round B: Their biggest pain point in this area

**Ask:**

> "In the area this ask touches, what hurts them most right now? The acute one, not the chronic one. The thing that is on fire this quarter, or this month. The thing they would pay to make go away."

**Push** (if thin):

> "If they were venting to a peer about this domain over coffee, what would they vent about? That is the pain point we are targeting."

### Round C: The bridge

**Ask:**

> "What is the bridge between your ask and their pain? In one sentence, how does this ask make their pain smaller, their number better, their decision easier? Write it the way they would say it back."

**This is the line.** If they nod when you say it back, the strategy is most of the way there.

**Summarize back:** *"They own `<X>`. Their pain is `<Y>`. The bridge: `<one sentence in their voice>`."*

**Push if the bridge is forced** ("we will help them with what they care about"):

> "That is still your language. The bridge is too clean. What is the real, slightly uncomfortable version of what is in it for them?"

Do not move on until the bridge sounds like something *they* would say.

## Phase 6: Name the Friction

*Three prompts. Each unlocks the next.*

### Surface objection

> "What will they say out loud when you bring this up? What is the version they say in the meeting?"

### Real objection

> "What is actually in the way? The thing under the surface objection. The political cost, the career risk, the relationship debt, the pile of work they would inherit."

**Push** (if user gives the surface twice):

> "Why would a reasonable person say no to this, given what they own? What part of their world gets harder, smaller, or more uncertain if they say yes?"

### Cost of yes

> "What would it cost them to say yes? Time, political capital, headcount, scope they would have to give up, a public position they would have to take. Name it. The size of the cost tells you how small the first yes has to be."

**Summarize back:** *"Surface: `<X>`. Real: `<Y>`. Cost of yes: `<Z>`."*

## Phase 7: Pick the Strategy

*One, not five. Influence by stacking is influence by spam.*

**AskUserQuestion:**

> **Which strategy fits this person and this goal?**
> - **Data.** Numbers they cannot argue with. Fits people who decide on evidence and own a number.
> - **Story.** A Tension → Insight → Outcome that makes the abstract concrete. Fits people who decide on narrative.
> - **Credibility.** Borrow trust: a name, a precedent, an outside expert. Fits people who trust authority signals.
> - **Aligned goals.** Reframe the ask in the language of what they already own. Fits people who resist anything not framed in their world.

If the user wants a fifth option, offer:

> **Social proof.** Who else is already in. Peer pressure for grown-ups. Fits people who hate being last or being first.

**Then ask:**

> "Why this one? Read it against their map. What about how they decide tells you this is the lever?"

The justification matters. If the user picks "data" for someone whose map says they decide on story, push back once. **Strategy matches the person, not the user's comfort zone.**

**Summarize back:** *"Strategy: `<name>`. Why: `<one sentence>`."*

## Phase 8: Define the First Yes

*The micro-commitment. Not the big ask. The visible next step that makes the big ask easier next time.*

**Ask:**

> "What is the smallest visible step you can take this week that moves them toward the big yes without asking for the big yes? A 15-minute conversation. A look at a one-pager. A nod on a single assumption. An intro to one person. Sign-off on a pilot scope, not a pilot."

**Push** (if too big, e.g. "get them to commit to the rollout"):

> "Too big to say yes to in one move. What is one notch smaller? What is the move that, if they say yes, gives you a foot in the door for the next conversation?"

**Then two follow-ups:**

> "By when do you make this move?"

> "What does 'yes' sound like? In their words. The exact sentence or signal that tells you the door is open."

**Summarize back:** *"Move: `<small visible step>`. By `<date>`. Yes sounds like: `<signal>`."*

## Phase 9: Draft the Move

*The strategy made into words. This is what goes in `## The move (drafted)`.*

**Ask channel/format** (if the audience map did not pin it):

> "Channel and format. Slack DM, email, 1:1 in person, a slide in a deck, a hallway moment. Pull from their map. What is the right surface for this move?"

**Then draft the move**, in the user's voice, matching the audience's format.

### Drafting rules

- **Open with their world.** Acknowledge what they own or worry about *before* stating the ask. The first sentence earns the right to the second.
- **Frame the ask in their language.** Use the bridge from Phase 5. Not "this enhances our product features." More like "this cuts the ad spend you are reviewing in the QBR by X percent."
- **Strip everything the map says shuts them down.** No methodology, no preamble, no "I wanted to share..." if their map flags those.
- **End with the first yes.** Last line is the smallest possible ask, phrased so a yes is one word.
- **Match their voice and length tolerance.** If their map says three minutes of reading max, three paragraphs max.
- **No em dashes or en dashes anywhere.** Vault convention. Commas, colons, periods, parens. The arrow glyph is fine.
- **Do not fabricate facts.** If the user gave you a vague number, leave `[X percent]`, `[N weeks]`. Better an honest gap than a confident lie.

Show the draft inline before generating the note, so the user can sharpen it.

## Phase 10: Generate the Influence Plan Note

**Filename:** `Influence - <Name> - <Topic> (YYYY-MM-DD).md` in `03 Stakeholder Drafts/`. Use today's real date.

Example: `Influence - Sarah - Q3 budget reallocation (2026-06-03).md`. If a file with that name already exists, append a short qualifier (e.g. ` v2`) rather than overwrite.

### Frontmatter

```yaml
---
type: note
module: "03 Stakeholder Drafts"
session: "Session 1"
framework: "Influence Strategy Canvas"
status: draft
stakeholder: <First Name>
strategy: <Data / Story / Credibility / Aligned goals / Social proof>
project: <project name if any, else omit the line>
date: <YYYY-MM-DD>
tags: [influence, stakeholder-drafts, <name-lowercased>]
publish: true
---
```

`publish: false`. Real influence plans are private.

### Body

Match the template structure exactly:

```markdown
# Influence Plan: <Goal in one line>

Related: [[<their Audience Map>]] (and [[<Project root note>]] if a project is linked)

---

## The goal

- **What I am trying to move:** <decision, resource, alignment, or permission, from Phase 2>
- **By when:** <date or window from Phase 2>
- **Why now:** <one sentence from Phase 2>

## The person

- **Name & role:** <Name>, <Role>
- **Audience Map:** [[<their Audience Map>]]
- **What motivates them in this decision:** <Phase 5 Rounds A and B. What they own plus the pain. Two lines if needed. Not their job description.>

## The friction

- **Surface objection:** <from Phase 6>
- **Real objection (what is actually in the way):** <from Phase 6>
- **What it would cost them to say yes:** <from Phase 6>

## Strategy

- [ ] **Data.**
- [ ] **Story.**
- [ ] **Credibility.**
- [ ] **Aligned goals.**
- [ ] **Social proof.**

(Tick the one chosen.)

**Why this one:** <from Phase 7>

**The bridge (the ask in their language):** <Phase 5 Round C sentence>

## First yes

- **The move:** <from Phase 8>
- **By when:** <from Phase 8>
- **What "yes" sounds like:** <from Phase 8>

## The move (drafted)

(<channel and format note from Phase 9>)

<the polished message or talking points, in the user's voice, in the audience's format>

---

## Follow-up

- **What happened:** 
- **Next move:** 
- **What I learned about how to move this person:** *(feeds back into their Audience Map)*
```

### Generation rules

- **Don't fabricate.** Thin answer, thin section. Placeholder in square brackets is fine. A confident lie is not.
- **Use their words for the bridge.** Phase 5 Round C appears in the plan in the audience's voice, not the user's.
- **Lead each section with the punchline.** No preamble. No "this section covers...".
- **No em dashes or en dashes anywhere.** Vault convention.

## Phase 11: Review & Confirm

Show the full generated plan. **Ask:**

> "Here is the plan and the drafted move. Three things to check: does the bridge sound like *them* (not you), is the strategy a fit for how they decide, and is the first yes small enough that no is irrational? Anything to sharpen before I save?"

Make targeted edits to what they flag. Don't regenerate the whole document. Loop until they say it's good.

Write the file only after explicit confirmation. Save to `03 Stakeholder Drafts/Influence - <Name> - <Topic> (YYYY-MM-DD).md`.

## Phase 12: Cross-link the Map and the Project

*Keeps the graph connected. The plan lives in `03 Stakeholder Drafts/`; the audience map and the project need to know.*

### Step A: Update the audience map

Read the map. Find the `## Current state of the relationship` section, or, failing that, append a new `## Open influence plans` section.

**Propose before applying:**

> "I'll add a line to `<Name>`'s map under 'Current state of the relationship' linking to this plan. The line will read: `'Open influence move: <goal in one line>. See [[Influence - <Name> - <Topic> (YYYY-MM-DD)]].'` Okay to apply?"

On explicit yes, edit the map. **One additive line. Do not regenerate. Do not touch any other section.**

### Step B: Update the project (if a project was linked in Phase 4)

Read the project's `CLAUDE.md`. Find a "Stakeholders" or "Key people" section, or propose appending a `## Influence moves in flight` section.

**Propose before applying:**

> "I'll add a line to `<Project>`'s CLAUDE.md noting an open influence move on `<Name>`: `<goal in one line>`. See `[[Influence - <Name> - <Topic> (YYYY-MM-DD)]]`. Okay to apply?"

On explicit yes, edit the project file. **One additive line. No regeneration.** If the project has a more specific home for this (a stakeholder note, a tracker file), surface that as the better target and let the user choose.

### Step C: Confirm what was touched

List the files in one line each:

- `[[03 Stakeholder Drafts/Influence - <Name> - <Topic> (YYYY-MM-DD)]]` (created)
- `[[02 Audience Mapping/<Name> (<Role>)]]` (added one link if approved)
- `[[11 Projects/<Project>/CLAUDE.md]]` (added one link if approved)

## Phase 13: Wrap

After saving, tell the user:

1. **Plan saved** at `[[03 Stakeholder Drafts/Influence - <Name> - <Topic> (YYYY-MM-DD)]]`.
2. **It is set to `publish: false`** so the real plan stays private even if Obsidian Publish is on.
3. **The drafted move is in `## The move (drafted)`.** Copy from there, send in the channel the audience map specifies. Edit once before sending so it sounds like you, not the bot.
4. **The first yes is the actual point.** Not the big ask. A single small visible step that makes the next conversation easier. Calendar it for the date you set.
5. **If they say no or stall**, the *frame* was wrong, not the words. Come back to Phase 5 and re-translate the ask into their world. Do not rewrite prose around a wrong bridge.
6. **Fill in the Follow-up section** after the move lands. Over time `03 Stakeholder Drafts/` becomes your private record of what actually moves which people.

Do not offer to scaffold notes in other folders. Keep this skill focused on the plan and its two cross-links.

## Critical Rules

- **Goal first, person second, project third.** No drafting until all three are locked.
- **Audience map is non-negotiable.** No Phase 5 bridging until the map is read (or the five basics captured inline). Generic influence is no influence.
- **The bridge is in *their* language, not yours.** Phase 5 Round C is the single most important sentence in the whole plan. If it still sounds like the user's pitch, the move will not land. Push once. If still flat, name it: *"We do not have the bridge yet. The plan will be soft until we do."*
- **One strategy, not five.** Influence by stacking is influence by spam. Pick the one that matches how this person decides.
- **First yes must be small enough that no is irrational.** If the user proposes "get them to commit to X", that is the big ask. Find the move one notch smaller, and one notch smaller again if needed.
- **One probe per thin answer, then move on.** Don't interrogate.
- **Use their words.** Mirror the user's phrasing in the spine. Mirror the audience's expectations in the drafted move.
- **Never fabricate.** Thin material, thin draft, with placeholders for what is missing. Never invent a number, motivation, timeline, or quote.
- **Cross-links are additive, never destructive.** One line added. Never regenerate. Always confirm before editing.
- **Don't touch EXAMPLE or Template files.** Read them for calibration. Never edit them as part of this skill run.
- **Spine before prose.** If the user asks you to "just write the message" before the goal, person, bridge, and first yes are locked, push back once: *"Let me lock the bridge and the first yes first. The message writes itself after that."* Then do it.
