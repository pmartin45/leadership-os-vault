---
type: readme
module: "Vault root"
session: "Pre-Work"
framework: ""
tags: [readme, home]
publish: true
---

# Leadership OS Vault

> **Start here.** This README is the front door of the vault. Read it end to end before opening anything else. Every other folder assumes you have done the setup below.

Welcome. This is your Leadership Operating System, a personal knowledge vault you own forever.

You're holding the empty version. Over the cohort, you'll populate it with your real stakeholders, your real messages, your real rhythm. By Demo Day, this vault is yours: not rented, not subscription-locked, not dependent on anyone else's server.

## Before Session 1, do these in order

1. **Open this folder in Obsidian.** File → Open folder as vault → select this folder.
2. **Run the `Brain Setup` skill.** This is mandatory and must happen before anything else in the vault. In your Claude session, invoke the skill at [[00 - Brain Setup Skill]] (just ask Claude to "run the Brain Setup skill"). It scans the vault, interviews you in five short rounds, and writes a personalized `CLAUDE.md` so Claude becomes a useful thinking partner for *your* leadership context. Without this step, every later skill ([[00 Skills/02 - Audience Map Builder Skill|Audience Map Builder]], drafting, sparring) is working blind.
3. **Work through the Pre-Work Bootcamp in the Maven portal.** It's the set of short setup videos that walk you through Obsidian, your Claude Project, the Sarah example, and how to fill in your Leadership Profile. Follow them in order.
4. **Read the examples.** Open `01 Leadership Profile/EXAMPLE - Alex Park.md`, then `02 Audience Mapping/EXAMPLE - Sarah (CMO).md`, then `03 Stakeholder Drafts/EXAMPLE - Message to Sarah re Churn Model.md`. See what "done" looks like.
5. **Fill in your `01 Leadership Profile/Leadership Profile.md`.** This is the foundation everything else builds on, and it is the context your Claude Project pulls from every session. 15 minutes. (Prefer to be walked through it? Run the [[00 Skills/01 - Leadership Profile Skill|Leadership Profile skill]] instead, it writes each section to the file as you answer.)
6. **Watch the two pre-watch videos.** *Why Smart Data Leaders Don't Get Invited to the Room* (15 min) and *Saying No Without Losing Trust* (8 min).

## The folders

| # | Folder | Unlocks |
|---|---|---|
| 01 | Leadership Profile | Pre-Work |
| 02 | Audience Mapping | Session 1 |
| 03 | Stakeholder Drafts | Session 1 |
| 04 | Storytelling | Session 1 |
| 05 | Change Communication | Session 2 |
| 06 | Delegation Briefs | Session 3 |
| 07 | Weekly Updates | Session 3 |
| 08 | Prioritization | Session 4 |
| 09 | Decision Log | Session 4 |
| 10 | AI Sparring | Ongoing from Session 1 |
| 11 | Projects | Ongoing, create one with the New Project skill |

The full skill catalog lives in `00 Skills/` (see [[00 Skills/README]] for the index). The standard every file follows is documented in `_Reference - Vault Conventions.md`.

## Three things to know

**1. The vault is the memory. Claude is the sparring partner.**
You'll pair this vault with a Claude Project called "My Leadership OS." Your profile, your audience maps, your past drafts, all of it lives here and gets pasted into Claude when you want to think with it. Claude does not remember between sessions. The vault does.

**2. The `_Template` files are the patterns. Do not edit them, duplicate them.**
Files starting with `_Template` are blueprints. Right-click → Make a copy, then rename. The underscore keeps templates sorted to the top of each folder.

**3. The EXAMPLE files show you what "done" looks like.**
Each framework folder ships with an EXAMPLE file built on the running case: Sarah (CMO), Priya (CFO), Daniel (Senior Analyst), and Marcus (Data Engineer), all working a customer churn prediction model. Read those first before filling your own.

## Questions during the cohort

Drop them in the cohort thread. Everything in this vault is iterable. If a template does not fit how you work, change it. This is your OS.
