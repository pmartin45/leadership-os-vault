---
type: template
module: "10 AI Sparring"
session: "Ongoing"
framework: ""
status: template
tags: [template, ai-sparring]
publish: true
---

# Sparring: [Topic]

> Duplicate this file, rename it to the topic and date. Paste the part of the exchange that changed your thinking, then write the takeaway.

## What I brought

*(The message, decision, or framing I came in with.)*

-

## Where Claude pushed back

*(The challenge, the disconfirming evidence, the reframe. Paste the exchange or summarise the turn.)*

-

## What I changed

*(What I did differently because of it.)*

-

## The one line I am keeping

*(The lesson, in a sentence.)*

-
