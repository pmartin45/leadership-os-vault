---
type: readme
module: "10 AI Sparring"
session: "Ongoing"
framework: ""
tags: [readme, ai-sparring]
publish: true
---

# 10 AI Sparring

The record of your thinking, not just your outputs. When you spar with Claude on a hard message or a hard decision, the transcript that taught you something gets saved here.

## What lives here

- **Saved transcripts of the sparring sessions worth keeping**: the moment Claude pushed back and changed how you framed something, the decision it red-teamed, the message it sharpened.
- **A worked example** so you can see what is worth capturing.

## How it grows

**Ongoing from Session 1.** Whenever a sparring session moves your thinking, duplicate `_Template - Sparring Transcript.md`, paste the exchange, and write the one line you took from it.

**Over the cohort**: this becomes the honest record of how your judgment changed, which is the heart of the Demo Day "what worked and what did not" slide.

## The rules

- **Capture the turn, not the whole chat.** The part where your thinking changed.
- **Always write the takeaway.** A transcript with no lesson is just scrollback.
- **Keep sensitive context out of what you publish.** Set `publish: false` on anything with private detail.
