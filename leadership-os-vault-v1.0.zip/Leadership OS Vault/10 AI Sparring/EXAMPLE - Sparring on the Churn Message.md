---
type: example
module: "10 AI Sparring"
session: "Session 1"
framework: "T→I→O"
status: active
tags: [running-case, ai-sparring, sarah]
publish: true
---

# Sparring: The Churn Message to Sarah

> Worked example. Do not edit. Use it as a reference for what is worth capturing.

## What I brought

- A draft to [[EXAMPLE - Sarah (CMO)|Sarah]] that opened with the model: logistic regression, 0.82 AUC, the segment definitions. I wanted her to approve two more weeks.

## Where Claude pushed back

- It flagged that I was leading with methodology, the exact thing her Audience Map says makes her shut down. It pointed out that "the data is wrong" last week was not about the numbers, it was about a gap I had not explained. It told me to cut the AUC line entirely and open with her own words back to her.

## What I changed

- Rewrote the open to lead with the tension she feels, a fragmented retention story for the QBR, not the analysis. Moved the segment insight to the middle. Closed with a question only she can answer. See [[EXAMPLE - Message to Sarah re Churn Model]].

## The one line I am keeping

- When a stakeholder says "the data is wrong," they are usually not disputing the numbers. They are telling me the framing has not landed.
