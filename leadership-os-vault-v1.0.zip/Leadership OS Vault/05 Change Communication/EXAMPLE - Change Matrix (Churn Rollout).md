---
type: example
module: "05 Change Communication"
session: "Session 2"
framework: "Change Response Matrix"
status: active
tags: [running-case, change-communication]
publish: true
---

# Churn Rollout: Matrix

> Worked example. Do not edit. Use it as a reference for mapping your own change.

---

## The change I'm leading

**The change I'm currently leading is** rolling the churn model out across every customer segment and wiring it into the campaign engine.

**The resistance I'm seeing, or quietly bracing for, is** Daniel relitigating the segment definitions in every meeting, and Marcus going silent on the rollout thread.

---

## The four people in the room

### Skeptic (vocal, resisting)

- **Name:** Daniel (Senior Analyst). See [[EXAMPLE - Daniel (Senior Analyst)]].
- **What they're pushing back on:** The segment definitions. He keeps reopening them, because validation is really his to own and he has not been told that out loud.
- **Move →** Put him on validation, named and credited. A won-over skeptic is the strongest proof. See [[EXAMPLE - Daniel - Churn Validation]].

### Advocate (vocal, on board)

- **Name:** Sarah (CMO). See [[EXAMPLE - Sarah (CMO)]].
- **What they're already saying out loud:** That she needs the retention story for the QBR.
- **Move →** Give her the one-page retention narrative to carry into the QBR. Let her sell it upward.

### ⭐ Withdrawn (quiet, resisting)

- **Name:** Marcus (Data Engineer). See [[EXAMPLE - Marcus (Data Engineer)]].
- **What they've gone quiet about:** The rollout wiring into the campaign engine, which lands on his pipelines. He stopped replying on the thread.
- **Move →** Go to him 1:1. Walk through the plan before it is announced and let his concerns shape the timeline. Surface the fear before it spreads. The message is in [[EXAMPLE - C.O.R.E. Message to Marcus]].

### Observer (quiet, on board)

- **Name:** Priya (CFO). See [[EXAMPLE - Priya (CFO)]].
- **What they're waiting to see:** The ROI before she fully commits the budget.
- **Move →** Show her the pilot number on one slide: €146K recovered in two weeks, roughly 14x on €8K spend. Evidence pulls her in.

---

## This week's move

Start in the quiet corner.

- [ ] **The conversation I'm having, and with whom:** 1:1 with Marcus, walk through the rollout plan.
- [ ] **By when:** Before the rollout is announced on the team thread.
- [ ] **What "yes" sounds like:** "Here is what I need on the pipeline side, and here is a timeline that works." The Small Yes.

---

## Notes

The starred Withdrawn corner is the riskiest and the most ignored. Marcus going quiet is the signal, not the absence of one.
