---
type: template
module: "05 Change Communication"
session: "Session 2"
framework: "Change Response Matrix"
status: template
tags: [template, change-communication]
publish: true
---

# [Change name]: Matrix

*Pre-work seed → Session 2 build → ongoing reference.*

---

## The change I'm leading

**The change I'm currently leading is** _____.

**The resistance I'm seeing, or quietly bracing for, is** _____.

Push yourself: be specific about *people*, not "the team." Names beat nouns.

---

## The four people in the room

Pick four real people the change touches. Place each by name in the right quadrant. Write one line on what they are *actually* doing, or pointedly *not* doing. Then write the **Move**: the single next action you will take with them.

### Skeptic (vocal, resisting)

- **Name:** 
- **What they're pushing back on (in their words):** 
- **Move →** *Invite the objection. Put them on validation. A won-over skeptic is your strongest proof.*

### Advocate (vocal, on board)

- **Name:** 
- **What they're already saying out loud:** 
- **Move →** *Give them something to carry to people you cannot reach.*

### ⭐ Withdrawn (quiet, resisting)

- **Name:** 
- **What they've gone quiet about:** 
- **Move →** *Go to them 1:1. Surface the fear before it spreads as a story.*

### Observer (quiet, on board)

- **Name:** 
- **What they're waiting to see:** 
- **Move →** *Show them one small, visible win. Pressure pushes them back; evidence pulls them in.*

---

## This week's move

Start in the quiet corner.

- [ ] **The conversation I'm having, and with whom:** 
- [ ] **By when:** 
- [ ] **What "yes" sounds like:** *(the smallest agreement I could get this week, the Small Yes)*

---

## Notes

(Context that does not fit above. What changed. What to revisit next week.)
