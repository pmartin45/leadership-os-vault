---
type: example
module: "05 Change Communication"
session: "Session 2"
framework: "C.O.R.E."
status: sent
tags: [running-case, change-communication, marcus]
publish: true
---

# Marcus: C.O.R.E. Message

*Drafted in My Leadership OS. Edited to sound like me. Ready to send.*

Related: [[EXAMPLE - Change Matrix (Churn Rollout)]]

---

## Who this is for

- **Name & role:** Marcus, Data Engineer. See [[EXAMPLE - Marcus (Data Engineer)]].
- **Their quadrant:** Withdrawn
- **What they're actually afraid of:** That the rollout timeline was set without him and will land on his pipelines as a fire drill.

---

## The message: C.O.R.E.

**Context.** We are moving to wire the churn model into the campaign engine. That runs on your pipelines, and I realised the timeline got shaped without you in the room.

**Outcome.** What good looks like: a rollout plan where the pipeline work is scoped by you, on a timeline you signed off, with no surprise load.

**Relevance.** This is your infrastructure. Nobody knows the failure modes better than you, and I would rather build the plan around what you see than discover it in production.

**Expectations.** I am not asking you to absorb this on top of everything. I am asking for 30 minutes this week to walk through it, and then the pipeline scope and timeline are yours to set. What will not change: you own the pipeline decisions.

---

## The version I'm sending

(Sent async, as his map says, not a calendar ambush.)

Marcus, the churn rollout touches your pipelines and the timeline got set without you. That is on me. Can we take 30 minutes this week so you can scope the pipeline work and set a timeline that actually holds? I would rather build the plan around what you see coming than find it in production. The pipeline calls stay yours.

---

## Status

- [x] Drafted in Claude using the C.O.R.E. prompt
- [x] One real edit made (so it sounds like me, not the bot)
- [x] Names the actual fear, not the surface objection
- [ ] Sent, on ______ via Slack DM
- [ ] Their response / what landed:

---

## Notes

Async and specific, because his map says a big public thread is exactly what makes him disappear. The point of the message is to convert silence into one Small Yes: a 30-minute conversation.
