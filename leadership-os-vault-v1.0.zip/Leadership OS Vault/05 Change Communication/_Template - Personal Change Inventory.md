---
type: template
module: "05 Change Communication"
session: "Session 2"
framework: "Personal Change Inventory"
status: template
tags: [template, change-communication, self-reflection]
publish: true
---

# Personal Change Inventory: [The change]

> Before you communicate change to anyone else, process it yourself. Twenty quiet minutes. The team reads your steadiness long before they read your message. If you are reactive, the message will be too.

Related: [[_Template - Change Matrix]], [[_Template - C.O.R.E. Message]]

---

## What is changing

*State it plainly, the way you would tell a friend. No corporate framing.*

- 

## What is clear and what is not

- **What I actually know:** 
- **What I am guessing at:** 
- **What I will not know for a while:** 

## How it is landing on me

*Name the feeling before it leaks into the message. Anxiety, relief, anger, grief, excitement, all valid, none of them strategy.*

- 

## The three spheres

### In my control

*The things I can decide today. Usually smaller than it feels in the middle of the night.*

- 

### In my influence

*The things I can shape with a conversation, a draft, a question. Not decide, shape.*

- 

### Outside my control

*Name them so they stop renting space. Once written down, they get smaller.*

- 

## Reset anchor statement

*One sentence to come back to when the noise spikes. Not a slogan, a sentence that is true. Read it before the next hard meeting.*

> 

---

## What this changes about how I show up this week

- **The conversation I am ready for now that I was not yesterday:** 
- **The one I am still not ready for:** 
- **What I will protect (focus time, a 1:1, a workout) so I do not lead this from depletion:** 
