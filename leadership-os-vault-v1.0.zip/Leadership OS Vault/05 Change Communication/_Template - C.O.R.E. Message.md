---
type: template
module: "05 Change Communication"
session: "Session 2"
framework: "C.O.R.E."
status: template
tags: [template, change-communication]
publish: true
---

# [Person's name]: C.O.R.E. Message

*Drafted in My Leadership OS. Edited to sound like me. Ready to send, or the draft I am still wrestling with.*

Related: [[_Template - Change Matrix]]

---

## Who this is for

- **Name & role:** 
- **Their quadrant:** Skeptic / Withdrawn / Observer / Advocate
- **What they're actually afraid of (one sentence, not the surface objection):** 

---

## The message: C.O.R.E.

**Context.** *What is changing, and why now.*

**Outcome.** *What "good" looks like.*

**Relevance.** *Why this matters to them, in their world.*

**Expectations.** *What I need from them, and what will not change.*

---

## Anticipated reactions

*How will they likely feel when they hear this? Name it before they do. One line of empathy acknowledgment to open with, so the message lands as a conversation, not a verdict.*

- **What they will feel:** 
- **The line I open with to acknowledge it:** 

## Reinforcement plan

*Trust through change is built by repetition, not a single send. Plan the next two touches before this one goes out.*

- **Touch 2 (within 1 week):** *(channel, format, what I will reinforce)*
- **Touch 3 (within 2-3 weeks):** *(what evidence I will be able to show by then)*

---

## The version I'm sending

(Paste the polished final here: Slack, email, or talking points for a 1:1.)

[your message, ready to send]

---

## Status

- [ ] Drafted in Claude using the C.O.R.E. prompt
- [ ] One real edit made (so it sounds like me, not the bot)
- [ ] Names the actual fear, not the surface objection
- [ ] Sent, on ______ via ______
- [ ] Their response / what landed:

---

## Notes

(How it went. What I would change next time. What it taught me about this person.)
