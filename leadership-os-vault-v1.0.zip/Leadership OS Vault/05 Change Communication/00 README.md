---
type: readme
module: "05 Change Communication"
session: "Session 2"
framework: "Change Response Matrix"
tags: [readme, change-communication]
publish: true
---

# 05 Change Communication

This is where you do the work of leading change, not just announcing it.

## What lives here

- **A Matrix note for each change you're leading.** The change named honestly, the four real people in your room, and the move each one needs.
- **A C.O.R.E. message for each skeptic.** Generated in your Claude Project, edited to sound like you, ready to send.
- **A Personal Change Inventory** for any change you are personally going through. Names what is changing, what you are losing, what you are gaining, and the move you owe yourself. Use it before drafting C.O.R.E. messages for others, so you are clear on your own position first.

## How it grows

**Pre-work for Session 2** plants the seed. Duplicate `_Template - Change Matrix.md`, rename it after your current change, and write the opening paragraph. That is all pre-work asks for.

**Session 2** fills it out. Names in each quadrant. Moves written. The Withdrawn corner starred. Then a C.O.R.E. message drafted in Claude for your hardest person, saved here as a second note.

**After Session 2**: every new change you lead earns its own pair of notes here. Same shape, every time. That is the system.

## The rules

- **Real changes only.** Not hypotheticals.
- **Real names in every quadrant.** *"There's some resistance"* does not count. *"Daniel has gone quiet in the last three standups"* does.
- **Start in the quiet corner.** The Withdrawn person is the riskiest and the most ignored.
- **Save the C.O.R.E. message even if you do not send it.** The draft is the point. It forces you to name the fear.

## Produced by

- **[[00 Skills/05 - C.O.R.E. Message Skill|C.O.R.E. Message skill]]**: pulls the Leadership Profile and the relevant Audience Map, names the actual fear, and drafts a C.O.R.E. (Context / Outcome / Relevance / Expectations) message with an empathy opener and a two-touch reinforcement plan. Saves it here.
