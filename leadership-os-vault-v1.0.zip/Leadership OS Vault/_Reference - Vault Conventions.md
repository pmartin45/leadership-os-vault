---
type: reference
module: "Vault root"
session: "Ongoing"
framework: ""
tags: [reference, conventions, meta]
publish: false
---

# Vault Conventions

The standard every file follows, so the vault stays consistent, the graph stays connected, and it is clean enough to sync and publish. Keep this current whenever the structure changes.

## Folder map

| # | Folder | Holds |
|---|---|---|
| 01 | Leadership Profile | Role, team, top three stakeholders, top three challenges. Pasted into Claude to ground it. |
| 02 | Audience Mapping | One Audience Map per stakeholder. |
| 03 | Stakeholder Drafts | Influence Plans, each ending in a tailored message built from an Audience Map. |
| 04 | Storytelling | T→I→O work. |
| 05 | Change Communication | Change Response Matrix maps and C.O.R.E. messages. |
| 06 | Delegation Briefs | One brief per handed-off task, with the chosen level. |
| 07 | Weekly Updates | Time audit and O.D.A. weekly updates. |
| 08 | Prioritization | Backlog Triage, Priority Grid, RICE. |
| 09 | Decision Log | C.A.L.L. Decision Records. |
| 10 | AI Sparring | Saved transcripts of hard message or decision sparring. |
| 11 | Projects | Active projects. Each project is its own subfolder with its own `CLAUDE.md` and `COMMANDS.md`. Scaffolded by the New Project skill. |

## File naming

- Folder index: `00 README.md`
- Template: `_Template - <Name>.md`
- Example: `EXAMPLE - <Name>.md`
- Reference or guide: `_Reference - <Name>.md`
- Bases view: `<Name>.base`. A live table view of notes in the folder, filtered by tag and type. See `06 Delegation Briefs/Delegation.base` for the pattern.
- AI-generated file: prefix the filename with `(C) ` so it's clear at a glance the file came from Claude, not me.

The leading underscore sorts templates and references to the top of each folder. Use a plain hyphen with spaces inside names. No em or en dashes, in filenames or anywhere else.

## Projects (folder 11)

`11 Projects/` is structured differently from the other framework folders.

- Each project is a self-contained subfolder (e.g. `11 Projects/Client X Engagement/`).
- Every project has its own `CLAUDE.md` (project-specific context and prime directive) and `COMMANDS.md` (list of project-specific skills and commands).
- The project's own folder structure (numbered input → process → output folders, plus `XX` utility folders) is defined by the New Project skill at scaffold time, based on the interview answers. There is no fixed convention across projects, because every project's process is different.
- `11 Projects/(PROJECT TEMPLATE)/` is the seed the New Project skill duplicates. Keep it minimal: placeholder `CLAUDE.md`, placeholder `COMMANDS.md`, and a `README.md` explaining the template. Never add a nested `.obsidian/` folder.
- Active projects are registered in the root `CLAUDE.md` under "My Current Projects & Overviews" so the top-level context always knows what's in play.

## Frontmatter (Properties)

Every file opens with YAML frontmatter. Base keys, on every file:

- `type:` readme | template | example | reference | profile | skill | note
- `module:` the folder name in quotes, e.g. "06 Delegation Briefs"
- `session:` Pre-Work | Session 1 | Session 2 | Session 3 | Session 4 | Setup | Ongoing. For a folder README or template, this is the session where the framework is taught. For an EXAMPLE file built on a specific running-case character, it can be the session that character first matters in (e.g. Marcus appears in Session 2 change work, Daniel in Session 3 delegation), even if the folder's framework is Session 1.
- `framework:` the framework the file uses, or left blank
- `tags:` a list, lowercase and hyphenated
- `publish:` true or false (the Obsidian Publish include flag)

Working artifacts (templates, examples, live notes) also carry:

- `status:` template | draft | active | sent | open | decided

Type-specific keys, so the Bases views have fields to group on:

- Delegation brief: `owner`, `level_now`, `level_target`
- Decision record: `door` (one-way or two-way), `confidence` (number), `review` (date)
- Audience map: `stakeholder`, `stakeholder_role`
- Weekly update: `week`

## Linking

- Use wikilinks, `[[Note Name]]`. Never escaped brackets, never a bare prose pointer. The vault is set to shortest-path wikilinks, so `[[EXAMPLE - Sarah (CMO)]]` resolves on its own.
- Every example links to its framework reference and to the running-case notes it touches, so the graph connects.
- Never leave a `\[\[ \]\]` or a stray backslash from a converter. Those do not render as links.

## Voice

- No em dashes and no en dashes, anywhere. Use commas, colons, periods, parentheses, or a sentence break. The arrow glyph (→) is allowed, because the frameworks are named with it.
- Direct, concrete, executive-ready. Lead with the point. No corporate filler.
- Do not invent stakeholder details, numbers, or quotes. The running-case facts are fixed.

## Publish defaults

- READMEs, templates, references, and the running-case EXAMPLE files: `publish: true`.
- A student's real, filled-in notes: `publish: false`, so private leadership data never reaches a public site.

## The running case (fixed)

Sarah (CMO), Priya (CFO), Daniel (Senior Analyst, built the churn model), Marcus (Data Engineer, the Withdrawn one in the change). The case is a customer churn prediction model. The numbers are fixed in the context brain; do not change them.
