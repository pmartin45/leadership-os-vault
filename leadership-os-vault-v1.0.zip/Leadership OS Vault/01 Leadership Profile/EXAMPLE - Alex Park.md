---
type: example
module: "01 Leadership Profile"
session: "Pre-Work"
framework: ""
status: active
tags: [running-case, profile]
publish: true
---

# Leadership Profile: Alex Park

> Worked example. Do not edit. Use it as a reference for filling in your own.

## Basics

- **Name:** Alex Park
- **Role / title:** VP, Data Science & Analytics
- **Company / industry:** Verstand (B2B SaaS, about 600 employees, Series C)
- **Team size:** 8
- **Team structure:** 4 data scientists, 3 analysts, 1 ML engineer. Dotted line to the CFO's FP&A team for forecasting work.

## Top 3 stakeholders

1. **Sarah Chen, CMO:** Owns the revenue narrative. Wants pipeline contribution, brand health, campaign ROI. Says "the data is wrong" when the gap between her gut and the numbers is not explained. See [[EXAMPLE - Sarah (CMO)]].
2. **Priya Shah, CFO:** Wants the bottom-line impact in one number, the risk if I am wrong, no methodology. See [[EXAMPLE - Priya (CFO)]].
3. **Daniel Reyes, Senior Analyst (built the churn model):** My strongest technical hire. Wants to step into cross-functional ownership but freezes in rooms with marketing and finance. Whether I can move him from "covers his domain" to "carries the room" defines whether this team scales past me. See [[EXAMPLE - Daniel (Senior Analyst)]].

## Top 3 current challenges

1. Churn model technically ready, but Marketing keeps relitigating the segment definitions. Three meetings, no decision.
2. Daniel (senior analyst) is strong technically but will not speak up cross-functionally. I keep covering for him, which means he is not growing and I am a bottleneck. See [[EXAMPLE - Daniel (Senior Analyst)]].
3. My weekly update to the exec team has become a 12-bullet status dump. People have stopped reading it.

## Operating context

- **Company stage:** Series C scale-up, about 600 people, planning a Series D in 18 months
- **Where data sits in the org:** Under the CPO. New structure, was previously under the CTO until six months ago.
- **Key constraints:** Headcount frozen until Q3. Data warehouse migration eating about 30% of team capacity through end of year.

## How I write and speak

- **Default register:** Direct, dry, occasionally too terse. Working on warmer openings.
- **Words and phrases I use a lot:** "Here's where we are." "The trade-off is..." "What I'd recommend." "One thing I need from you."
- **Words and phrases I never use:** "Just circling back." "Per my last email." "Quick question." "Synergy" or anything that sounds like a deck.
- **My version of a great message:** One screen. Opens with the headline. Closes with a specific ask. No methodology unless they asked.

## Notes for Claude

- I lead a remote-first team across CET, EST, and PST. Async-first by default.
- I am 14 months into this role. Still building the relationship with Sarah and Priya. I have known my manager (CPO) for years, so the upward channel is in good shape.
- When drafting for the exec team, default to memo-style not slide-style. The CPO reads everything as prose, and the rest of the room follows his lead.
- I track everything in Notion personally but my team lives in Linear. Reference whichever the audience cares about.
