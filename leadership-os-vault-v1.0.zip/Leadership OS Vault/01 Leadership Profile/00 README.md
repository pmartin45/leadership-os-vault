---
type: readme
module: "01 Leadership Profile"
session: "Pre-Work"
framework: ""
tags: [readme, profile]
publish: true
---

# 01 Leadership Profile

The foundation. Everything else in this vault builds on what you write here, and it is the context your Claude Project pulls from every session.

## What lives here

- **Your Leadership Profile**: role, team, your top three stakeholders, your top three current challenges, and how you write and speak. Filled once, updated as your role evolves.
- **A worked example** (Alex Park) so you can see what a finished profile looks like before you write your own.

## How it grows

**Pre-work** fills it. Open `Leadership Profile.md`, read `EXAMPLE - Alex Park.md` first, then spend 15 minutes filling in your own. This is the one piece that has to be done before Session 1.

**After that**: update it when your team, your stakeholders, or your challenges change. A stale profile makes for stale sparring.

## The rules

- **Paste it into Claude to ground every session.** The profile is what stops Claude from guessing who you are.
- **Be honest about voice.** Claude drafts in your voice only if you tell it what your voice is.
- **Real stakeholders, real challenges.** Not the inbox, the substance.
