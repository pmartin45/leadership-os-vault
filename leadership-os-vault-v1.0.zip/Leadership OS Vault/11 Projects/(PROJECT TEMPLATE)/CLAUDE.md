# [Project Name]: Placeholder

> **This is a placeholder.** The **New Project** skill replaces this file with a real `CLAUDE.md` after interviewing you. If you're reading this inside a real project folder, the skill didn't finish, re-run it, or delete this file and write your own.

## What goes here (once the skill runs)

- One-paragraph description of what this project is
- Claude's role in this project + prime directive
- The process from idea to done
- Key people involved
- Folder structure
- Rules and conventions
- Current status

See the **New Project** skill ([[11 - New Project Skill]]) for the full template structure.
