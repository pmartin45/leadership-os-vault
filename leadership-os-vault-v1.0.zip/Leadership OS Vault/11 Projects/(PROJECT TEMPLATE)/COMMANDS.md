# Commands & Skills: Placeholder

> **This is a placeholder.** The **New Project** skill replaces this file with a real `COMMANDS.md` after interviewing you. If you're reading this inside a real project folder, the skill didn't finish, re-run it, or delete this file and write your own.

## What goes here (once the skill runs)

A quick-reference list of every project-specific skill and command available in this project. Starts empty and grows as you add automations.
