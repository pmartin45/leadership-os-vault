# (PROJECT TEMPLATE)

This folder is the seed the **New Project** skill duplicates when you start a new project. It is intentionally minimal.

## What's in here

- `CLAUDE.md`: placeholder. The New Project skill overwrites it with a real one after interviewing you.
- `COMMANDS.md`: placeholder. Same deal, the skill replaces it with the real command list for the new project.
- `README.md`: this file. The skill deletes it from the duplicated project, since it only explains the template.

## Why this template stays minimal

Two reasons:

1. **The parent vault's `.obsidian/` governs everything.** A nested `.obsidian/` folder inside a project would only add bloat and risk weird config drift. If one ever appears here, delete it, and delete it from the template too.
2. **Every project's process is different.** The skill creates the actual numbered folders (`00 Ideas/`, `01 In Progress/`, etc.) based on the interview answers, not from defaults baked in here. Carrying forward numbered folders that don't fit the next project just makes cleanup work.

## How to use this template

Don't duplicate it manually. Run the **New Project** skill ([[11 - New Project Skill]]), it handles the duplication, cleanup, and scaffolding for you.

## How to evolve this template

If you find yourself making the same edit to every new project right after the skill scaffolds it, that's a signal to fold it back into this template. Keep additions minimal, anything project-specific belongs in the project, not here.
