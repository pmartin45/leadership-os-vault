---
type: example
module: "02 Audience Mapping"
session: "Session 1"
framework: "Audience Mapping"
status: active
stakeholder: Sarah
stakeholder_role: CMO
tags: [running-case, audience-mapping, sarah]
publish: true
---

# Audience Map: Sarah (CMO)

## Who they are

- **Name:** Sarah Chen
- **Role / title:** Chief Marketing Officer
- **Relationship to you:** Peer on the leadership team. Owns the revenue narrative I support with data.

## What they care about most

- Pipeline quality and acquisition cost, her board metric
- Retention story for the next QBR. She is being asked "where is the leaky bucket?"
- Brand health, a quieter priority but hers personally

## What they're worried about right now

- Q3 CAC is trending the wrong way and she does not have a clean answer yet
- The retention narrative is fragmented across three dashboards and nobody owns it

## How they consume information

- **Format preference:** One page. If it is slides, max five. Hates 40-slide decks.
- **Length tolerance:** Three minutes of reading or she is skimming.
- **The "so what" first?** Yes. Always. Open with the decision she needs to make.

## What makes them shut down

- Leading with methodology. She does not want to hear about the model, she wants the answer.
- Numbers without a recommendation. "Here's the data" is not a finish line for her.
- When the data contradicts her gut and I do not acknowledge the gap. She will say "the data is wrong," and what she means is "explain the gap or I will not trust this."

## What a great outcome looks like for them

- She walks out with one number, one risk, one decision, one owner.

## Current state of the relationship

- Solid but bruised. She pushed back on the churn model timeline last sprint. I have not closed that loop yet. It needs a Tension → Insight → Outcome message this week. See [[EXAMPLE - Message to Sarah re Churn Model]].

## Notes for Claude

- Sarah is a cyclist. She thinks in cadence, watts, gradients. Metaphors from endurance sport land well. Do not force them, but they work.
- She writes in short paragraphs. Match her.
- Never open with "I wanted to share..." Open with the headline.
- When she says "the data is wrong," she is signalling distrust in framing, not numbers. Address the gap directly.
