---
type: readme
module: "02 Audience Mapping"
session: "Session 1"
framework: "Audience Mapping"
tags: [readme, audience-mapping]
publish: true
---

# 02 Audience Mapping

One map per stakeholder. The work of knowing your audience before you ever draft them a message.

## What lives here

- **An Audience Map for each stakeholder whose buy-in shapes your quarter**: what they care about, what they fear, how they consume information, what makes them shut down, and the one outcome that lands for them.
- **Worked examples** built on the running case: Sarah (CMO), Priya (CFO), Daniel (Senior Analyst), Marcus (Data Engineer).

## How it grows

**Pre-work** builds the Sarah example with you. **Session 1** has you map your real top three stakeholders. Duplicate `_Template - Audience Map.md`, rename it to the person, fill it in.

**After Session 1**: a new map every time a new stakeholder starts shaping your work.

## The rules

- **One detail outside the office.** Where resonance lives. Sarah is a cyclist; use it.
- **Name what makes them shut down.** The map is only useful if it is honest about the triggers.
- **Link the map to the messages you build from it**, so 03 Stakeholder Drafts connects back here.

## Produced by

- **[[00 Skills/02 - Audience Map Builder Skill|Audience Map Builder skill]]**: interviews you about a stakeholder (lean 3-round capture or deep 5-round map), branches questions by relationship type, and writes a populated map here.
