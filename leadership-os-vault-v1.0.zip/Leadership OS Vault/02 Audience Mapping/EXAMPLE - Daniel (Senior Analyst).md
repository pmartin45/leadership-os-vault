---
type: example
module: "02 Audience Mapping"
session: "Session 3"
framework: "Audience Mapping"
status: active
stakeholder: Daniel
stakeholder_role: Senior Analyst
tags: [running-case, audience-mapping, daniel]
publish: true
---

# Audience Map: Daniel (Senior Analyst)

## Who they are

- **Name:** Daniel
- **Role / title:** Senior Analyst (built the churn model)
- **Relationship to you:** Direct report. Your strongest technical person and your biggest delegation opportunity.

## What they care about most

- Doing technically excellent work and being recognised for it
- Knowing exactly what is his to decide and what is not
- Growing into a leader without being thrown in unsupported

## What they're worried about right now

- Quietly worried that AI makes his judgment redundant
- Unsure how visible he is allowed to be in cross-functional rooms

## How they consume information

- **Format preference:** Direct and specific. Clear scope, clear guardrails.
- **Length tolerance:** High for technical depth, low for vague direction.
- **The "so what" first?** Less than the execs. He wants the what and the boundaries.

## What makes them shut down

- Vague delegation. "Own this" with no level and no guardrails makes him ask for approval at every step.
- Being publicly corrected. It confirms his fear that his judgment is not trusted.
- Having his work quietly redone by me. It tells him he is still not the owner.

## What a great outcome looks like for them

- He owns a piece of work end to end, knows the exact guardrails, and gets credit for it in front of Sarah and Priya.

## Current state of the relationship

- Strong, but I am the bottleneck. I keep covering for him cross-functionally. The fix is a real delegation brief. See [[EXAMPLE - Daniel - Churn Validation]].

## Notes for Claude

- Name the delegation level explicitly. See [[_Reference - 7 Levels of Delegation]].
- Reassure on the AI fear by pointing him at judgment work, not task work.
- When drafting for Daniel, be concrete about scope and what is safe to decide.
