---
type: example
module: "02 Audience Mapping"
session: "Session 2"
framework: "Audience Mapping"
status: active
stakeholder: Priya
stakeholder_role: CFO
tags: [running-case, audience-mapping, priya]
publish: true
---

# Audience Map: Priya (CFO)

## Who they are

- **Name:** Priya
- **Role / title:** Chief Financial Officer
- **Relationship to you:** Peer on the leadership team. Holds the budget for anything you want to roll out.

## What they care about most

- Return on investment, stated as a number she can defend to the board
- The downside risk if the bet is wrong, named honestly and up front
- Payback period. How fast the spend comes back

## What they're worried about right now

- A flat budget and a queue of teams all sure their initiative is the priority
- Being asked to approve spend on a model she cannot personally evaluate

## How they consume information

- **Format preference:** The number and the risk on one slide. No appendix.
- **Length tolerance:** One slide, one minute.
- **The "so what" first?** Always. Lead with the ask and the return.

## What makes them shut down

- A live demo. She does not want to watch it work, she wants the business case.
- Methodology. AUC, SMOTE, and XGBoost are noise to her.
- A number with no risk attached. If you only show upside, she stops trusting it.

## What a great outcome looks like for them

- She approves in the room because the ask, the return, the risk, and the payback are all on one slide.

## Current state of the relationship

- Newer relationship. She has not seen me bring her a clean business case yet. The €90K churn rollout ask is the test. Build it as a T→I→O business case (Tension, Insight, Outcome) with the number, the risk, and the ask on one screen, not a demo.

## Notes for Claude

- Frame every ask as effect on the business, not features of the model.
- One slide. The number, the risk, the payback, the ask.
- Never propose a demo to Priya. Propose a decision.
