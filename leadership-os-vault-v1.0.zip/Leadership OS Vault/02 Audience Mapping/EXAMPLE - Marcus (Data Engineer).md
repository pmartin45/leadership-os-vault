---
type: example
module: "02 Audience Mapping"
session: "Session 2"
framework: "Audience Mapping"
status: active
stakeholder: Marcus
stakeholder_role: Data Engineer
tags: [running-case, audience-mapping, marcus]
publish: true
---

# Audience Map: Marcus (Data Engineer)

## Who they are

- **Name:** Marcus
- **Role / title:** Data Engineer
- **Relationship to you:** Direct report. Owns the pipelines the churn model runs on.

## What they care about most

- Systems that are stable and not held together with workarounds
- Being consulted before decisions that land on his infrastructure
- Quiet, uninterrupted build time

## What they're worried about right now

- The rollout wiring the model into the campaign engine, which lands squarely on his pipelines
- That the deployment timeline was set without him

## How they consume information

- **Format preference:** Written, async, specific. Not a meeting.
- **Length tolerance:** Detail is fine if it is relevant to his work.
- **The "so what" first?** He wants the impact on his systems first.

## What makes them shut down

- Being surprised by a decision that affects his work. He goes quiet rather than pushing back.
- Big public threads. He stops replying. He is the Withdrawn person on the rollout thread.
- Being told, not asked, about changes to his pipelines.

## What a great outcome looks like for them

- A 1:1 where the rollout plan is walked through with him before it is announced, and his concerns shape the timeline.

## Current state of the relationship

- He has gone quiet on the rollout thread. Classic Withdrawn. The move is to go to him 1:1 and surface the fear before it spreads. See the Withdrawn quadrant in [[EXAMPLE - Change Matrix (Churn Rollout)]].

## Notes for Claude

- Marcus does not resist loudly, he disappears. Silence is the signal.
- Draft async and specific, never a calendar invite as the first move.
- Lead with the impact on his pipelines and what I am asking him to shape, not just informing him.
